package tic_tac_toe.enumerations;

public enum Couleurs {
		
	JAUNE,
	VERT,
	BLACK;
}
