package tic_tac_toe.enumerations;

public enum Winner {
	
	JOUEUR1,
	JOUEUR2,
	JOUEUR3;

}
