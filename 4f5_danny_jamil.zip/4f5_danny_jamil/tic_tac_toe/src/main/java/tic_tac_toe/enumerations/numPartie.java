package tic_tac_toe.enumerations;

public enum numPartie {

	PARTIE1,
	PARTIE2,
	PARTIE3;
}
