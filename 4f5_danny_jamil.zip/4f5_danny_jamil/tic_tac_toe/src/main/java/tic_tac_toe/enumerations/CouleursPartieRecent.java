package tic_tac_toe.enumerations;

public enum CouleursPartieRecent {
	
	
	BLACK, BLUE
	
	

}
