package tic_tac_toe.pages.parametres;

import ntro.mvc.modeles.ModeleLectureSeule;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.enumerations.TailleGrille;

public interface ParametresLectureSeule extends ModeleLectureSeule {
	
	Forme getQuiCommence();
	TailleGrille getTailleGrille();
	

}
