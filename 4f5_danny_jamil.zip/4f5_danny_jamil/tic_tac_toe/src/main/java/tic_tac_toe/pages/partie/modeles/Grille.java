package tic_tac_toe.pages.partie.modeles;

import java.util.ArrayList;
import java.util.List;

import tic_tac_toe.enumerations.Forme;
import ntro.debogage.J;

public class Grille implements GrilleLectureSeule {

	protected List<Colonne> colonnes = new ArrayList<>();

	public void apresCreation() {
		J.appel(this);
		for (int i = 0; i < this.colonnes.size(); i++) {
			this.colonnes.get(i).setIdColonne(i);
		}
	}

	public void apresChargementJson() {
		for (int indiceColonne = 0; indiceColonne < colonnes.size(); indiceColonne++) {
			Colonne colonne = colonnes.get(indiceColonne);
			colonne.setIdColonne(indiceColonne);
			colonne.apresChargementJson(indiceColonne);
		}
	}

	public void ajouterCase(int idColonne, int indiceRangee, Forme forme) {
		J.appel(this);

		colonnes.get(idColonne).ajouterCase(forme, indiceRangee);
	}

	@Override
	public List<ColonneLectureSeule> getColonnes() {
		J.appel(this);

		List<ColonneLectureSeule> colonnesLectureSeule = new ArrayList<>();

		for (Colonne colonne : colonnes) {

			colonnesLectureSeule.add((ColonneLectureSeule) colonne);

		}

		return colonnesLectureSeule;

	}

	public boolean siPossibleJouerIci(int indiceColonne, int hauteur) {
		J.appel(this);

		boolean siPossible = false;

		if (siIndiceColonneValide(indiceColonne)) {

			siPossible = colonnes.get(indiceColonne).siPossibleJouerIci(hauteur);
		}

		return siPossible;
	}

	private boolean siIndiceColonneValide(int indiceColonne) {
		J.appel(this);

		return indiceColonne >= 0 && indiceColonne < colonnes.size();
	}
}
