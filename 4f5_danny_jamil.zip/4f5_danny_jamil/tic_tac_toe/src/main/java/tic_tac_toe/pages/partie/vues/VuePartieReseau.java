package tic_tac_toe.pages.partie.vues;

public class      VuePartieReseau 
       extends    VuePartie {

}
