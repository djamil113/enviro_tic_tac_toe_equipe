package tic_tac_toe.pages.partie.modeles;

public class PartieLocale extends Partie<PartieLocaleLectureSeule> implements PartieLocaleLectureSeule {

}
