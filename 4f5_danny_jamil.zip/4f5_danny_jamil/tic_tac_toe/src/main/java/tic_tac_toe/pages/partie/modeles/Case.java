package tic_tac_toe.pages.partie.modeles;

import tic_tac_toe.enumerations.Forme;
import ntro.debogage.J;

public class Case implements CaseLectureSeule {

	private Forme forme;
	private transient int indiceColonne;
	private int indiceRangee; // On va sauvegarder l'indice de la rangee dans la case pour qu'on sache ou la
														// forme se trouve dans la colonne

	@Override
	public Forme getForme() {
		J.appel(this);

		return forme;
	}

	@Override
	public int getIndiceRangee() {
		J.appel(this);

		return indiceRangee;
	}

	@Override
	public int getIndiceColonne() {
		J.appel(this);

		return indiceColonne;
	}

	public void setIndiceColonne(int indiceColonne) {
		J.appel(this);

		this.indiceColonne = indiceColonne;
	}

	public void setIndiceRangee(int indiceRangee) {
		J.appel(this);

		this.indiceRangee = indiceRangee;
	}

	public void setForme(Forme forme) {
		J.appel(this);

		this.forme = forme;
	}
}
