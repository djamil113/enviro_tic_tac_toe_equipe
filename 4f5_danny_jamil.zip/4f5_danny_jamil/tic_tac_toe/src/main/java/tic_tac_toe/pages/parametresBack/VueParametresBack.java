package tic_tac_toe.pages.parametresBack;


import java.awt.MultipleGradientPaint.ColorSpaceType;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import ntro.commandes.FabriqueCommande;
import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.Vue;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBackground;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBackgroundPourEnvoie;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBordure;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBordurePourEnvoie;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurForme;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurFormePourEnvoie;
import tic_tac_toe.pages.partie.composants.ButtonAjustable;
import tic_tac_toe.enumerations.Couleurs;
import tic_tac_toe.commandes.fermer_parametresBack.FermerParametresBack;
import tic_tac_toe.commandes.fermer_parametresBack.FermerParametresBackPourEnvoi;




public class VueParametresBack implements Vue, Initializable{
	
	private FermerParametresBackPourEnvoi fermerParametresBack;
	private ChoisirCouleurBackgroundPourEnvoie choisirCouleurBackground1;
	private ChoisirCouleurBordurePourEnvoie choisirCouleurBordure2;
	private ChoisirCouleurFormePourEnvoie choisirCouleurForme3;
	
	@FXML
	private CheckBox checkVert, checkJaune, checkBlack;

	@FXML
	private ButtonAjustable caseJaune, caseVert, caseBlack;
	
	@FXML
	private CheckBox check2Jaune, check2Vert, check2Black;

	@FXML
	private CheckBox checkBackJaune, checkBackVert, checkBackBlack;

	@FXML
	private Button boutonOk;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		J.appel(this);

		DoitEtre.nonNul(checkVert);
		DoitEtre.nonNul(checkBlack);
		DoitEtre.nonNul(checkJaune);
		DoitEtre.nonNul(caseBlack);
		DoitEtre.nonNul(caseJaune);
		DoitEtre.nonNul(caseVert);
		DoitEtre.nonNul(check2Jaune);
		DoitEtre.nonNul(check2Black);
		DoitEtre.nonNul(check2Vert);
		DoitEtre.nonNul(checkBackBlack);
		DoitEtre.nonNul(checkBackJaune);
		DoitEtre.nonNul(checkBackVert);
		DoitEtre.nonNul(boutonOk);

		fermerParametresBack = FabriqueCommande.obtenirCommandePourEnvoi(FermerParametresBack.class);

		caseJaune.afficherCouleur(Couleurs.JAUNE);
		caseBlack.afficherCouleur(Couleurs.BLACK);
		caseVert.afficherCouleur(Couleurs.VERT);

	
	}

	public void animation() {
		caseJaune.animerEntreeJeton();
		caseVert.animerEntreeJeton();
		caseBlack.animerEntreeJeton();
	}


	@Override
	public void obtenirCommandesPourEnvoi() {
		J.appel(this);
		
		fermerParametresBack = FabriqueCommande.obtenirCommandePourEnvoi(FermerParametresBack.class);
		choisirCouleurBackground1 = FabriqueCommande.obtenirCommandePourEnvoi(ChoisirCouleurBackground.class);
		choisirCouleurBordure2= FabriqueCommande.obtenirCommandePourEnvoi(ChoisirCouleurBordure.class);
		choisirCouleurForme3 = FabriqueCommande.obtenirCommandePourEnvoi(ChoisirCouleurForme.class);
	}
	@Override
	public void installerCapteursEvenementsUsager() {
		J.appel(this);
		//---------------------------------------------------------------------------
		//Forme :
		checkVert.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				choisirCouleurForme3.setCouleur(Couleurs.VERT);
				choisirCouleurForme3.envoyerCommande();
			}
		});

		
		checkJaune.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				choisirCouleurForme3.setCouleur(Couleurs.JAUNE);
				choisirCouleurForme3.envoyerCommande();
			}
		});
		
		checkBlack.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				choisirCouleurForme3.setCouleur(Couleurs.BLACK);
				choisirCouleurForme3.envoyerCommande();
			}
		});
		//---------------------------------------------------------------------------
		//Bordure :
		check2Vert.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				choisirCouleurBordure2.setCouleur(Couleurs.VERT);
				choisirCouleurBordure2.envoyerCommande();
			}
		});
		
		check2Jaune.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				choisirCouleurBordure2.setCouleur(Couleurs.JAUNE);
				choisirCouleurBordure2.envoyerCommande();
			}
		});
		
		check2Black.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				choisirCouleurBordure2.setCouleur(Couleurs.BLACK);
				choisirCouleurBordure2.envoyerCommande();
			}
		});
		//---------------------------------------------------------------------------
		// Background :
		checkBackVert.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				choisirCouleurBackground1.setCouleur(Couleurs.VERT);
				choisirCouleurBackground1.envoyerCommande();
			}
		});
		
		checkBackJaune.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				choisirCouleurBackground1.setCouleur(Couleurs.JAUNE);
				choisirCouleurBackground1.envoyerCommande();
			}
		});
		
		checkBackBlack.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				choisirCouleurBackground1.setCouleur(Couleurs.BLACK);
				choisirCouleurBackground1.envoyerCommande();
			}
		});
		
		boutonOk.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				fermerParametresBack.envoyerCommande();
			}
		});
		
	}

	@Override
	public void verifierCommandesPossibles() {
		J.appel(this);

	}

	public void afficheCouleurForme(Couleurs couleurs) {
		J.appel(this);

		DoitEtre.nonNul(couleurs);

		switch (couleurs) {

		case JAUNE:
			checkVert.setSelected(false);
			checkJaune.setSelected(true);
			checkBlack.setSelected(false);
			break;

		case VERT:
			checkVert.setSelected(true);
			checkJaune.setSelected(false);
			checkBlack.setSelected(false);
			break;

		case BLACK:
			checkVert.setSelected(false);
			checkJaune.setSelected(false);
			checkBlack.setSelected(true);
			break;
		}
		}
		public void afficheCouleurBordure(Couleurs couleurs) {
			J.appel(this);

			DoitEtre.nonNul(couleurs);

			switch (couleurs) {

			case JAUNE:
			check2Vert.setSelected(false);
			check2Jaune.setSelected(true);
			check2Black.setSelected(false);
				break;

			case VERT:
				check2Vert.setSelected(true);
				check2Jaune.setSelected(false);
				check2Black.setSelected(false);
				break;

			case BLACK:
				check2Vert.setSelected(false);
				check2Jaune.setSelected(false);
				check2Black.setSelected(true);
				break;

			}
			
	}
		public void afficheCouleurBackground(Couleurs couleurs) {
			J.appel(this);

			DoitEtre.nonNul(couleurs);

			switch (couleurs) {

			case JAUNE:
				checkBackBlack.setSelected(false);
				checkBackJaune.setSelected(true);
				checkBackVert.setSelected(false);
				break;

			case VERT:
				checkBackVert.setSelected(true);
				checkBackJaune.setSelected(false);
				checkBackBlack.setSelected(false);
				break;

			case BLACK:
				checkBackVert.setSelected(false);
				checkBackJaune.setSelected(false);
				checkBackBlack.setSelected(true);
				break;
			}
		}

}
