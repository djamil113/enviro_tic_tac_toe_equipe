package tic_tac_toe.pages.partie.modeles;

import ntro.debogage.J;
import ntro.mvc.modeles.Modele;
import tic_tac_toe.Constantes;
import tic_tac_toe.enumerations.Forme;

public class Partie<PLS extends PartieLectureSeule> extends Modele<PLS> implements PartieLectureSeule {

	protected transient int largeur;
	protected int hauteur;

	protected Forme formeCourante;

	protected Grille grille;

	@Override
	public void apresCreation() {
		J.appel(this);

		largeur = Constantes.TAILLE_GRILLE_PAR_DEFAUT.getLargeur();
		hauteur = Constantes.TAILLE_GRILLE_PAR_DEFAUT.getHauteur();
		formeCourante = Forme.X;

		initialiserGrille();
	}

	private void initialiserGrille() {
		J.appel(this);

		grille.apresCreation();
	}

	@Override
	public void apresChargementJson() {
		J.appel(this);

		largeur = grille.getColonnes().size();
		grille.apresChargementJson();
	}

	public void jouerIci(int indiceColonne, int indiceRangee) {
		J.appel(this);

		effectuerCoup(indiceColonne, indiceRangee);
	}

	public void effectuerCoup(int indiceColonne, int indiceRangee) {
		J.appel(this);

		grille.ajouterCase(indiceColonne, indiceRangee, formeCourante);
		prochaineForme();
	}

	private void prochaineForme() {
		J.appel(this);

		switch (formeCourante) {

		case X:
			formeCourante = Forme.O;
			break;
		case O:
			formeCourante = Forme.X;
			break;
		}
	}

	public int getLargeur() {
		J.appel(this);
		return largeur;
	}

	public void setLargeur(int largeur) {
		J.appel(this);
		this.largeur = largeur;

		initialiserGrille();
	}

	public int getHauteur() {
		J.appel(this);
		return hauteur;
	}

	public void setHauteur(int hauteur) {
		J.appel(this);
		this.hauteur = hauteur;

		initialiserGrille();
	}

	public Forme getFormeCourante() {
		J.appel(this);
		return formeCourante;
	}

	public void setFormeCourante(Forme formeCourante) {
		J.appel(this);
		this.formeCourante = formeCourante;
	}

	public GrilleLectureSeule getGrille() {
		J.appel(this);
		return (GrilleLectureSeule) grille;
	}

	public void setGrille(Grille grille) {
		J.appel(this);
		this.grille = grille;
	}

	public boolean siPossibleJouerIci(int indiceColonne) {
		J.appel(this);

		return grille.siPossibleJouerIci(indiceColonne, hauteur);
	}
}
