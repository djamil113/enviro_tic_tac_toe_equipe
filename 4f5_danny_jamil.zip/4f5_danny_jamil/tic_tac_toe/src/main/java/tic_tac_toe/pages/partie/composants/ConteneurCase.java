package tic_tac_toe.pages.partie.composants;

import ntro.debogage.J;
import tic_tac_toe.Constantes;
import tic_tac_toe.enumerations.Forme;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class ConteneurCase extends VBox {

	private Case[][] cases;

	public ConteneurCase() {

		J.appel(this);
	}

	public void creerCases(int largeur, int hauteur) {
		J.appel(this);

		cases = new Case[hauteur][largeur];
		
		for (int indiceRangee = 0; indiceRangee < hauteur; indiceRangee++) {
			HBox ligne = creerLignes(indiceRangee, largeur);

			this.getChildren().add(ligne);
		}
	}

	public HBox creerLignes(int indiceRangee, int largeur) {
		J.appel(this);

		HBox ligne = new HBox();
		
		this.getStyleClass().add("conteneurLigne");
		
		VBox.setVgrow(this, Priority.ALWAYS);

		for (int indiceColonne = 0; indiceColonne < largeur; indiceColonne++) {

			Case caseBouton = new Case(indiceRangee, indiceColonne);

			caseBouton.setMinWidth(Constantes.TAILLE_CASE);
			caseBouton.setMaxWidth(Constantes.TAILLE_CASE);

			caseBouton.setMinHeight(Constantes.TAILLE_CASE);
			caseBouton.setMaxHeight(Constantes.TAILLE_CASE);
			cases[indiceRangee][indiceColonne] = caseBouton;
			
			caseBouton.getStyleClass().add("conteneurCase");
			
			HBox.setHgrow(caseBouton, Priority.ALWAYS);

			ligne.getChildren().add(caseBouton);			
		}
		return ligne;
	}

	public void obtenirJouerIciPourEnvoi() {
		J.appel(this);

		for (int i = 0; i < cases.length; i++) {

			for (int j = 0; j < cases[i].length; j++) {

				cases[i][j].obtenirJouerIciPourEnvoi();
			}
		}
	}

	public void installerCapteursJouerIci() {
		J.appel(this);

		for (int i = 0; i < cases.length; i++) {

			for (int j = 0; j < cases[i].length; j++) {

				cases[i][j].installerCapteurJouerIci();
			}
		}
	}

	public Case[][] getCases() {
		J.appel(this);

		return this.cases;
	}

	public void afficherCase(int indiceColonne, int indiceRangee, Forme forme) {
		J.appel(this);
		J.valeurs(indiceColonne, indiceRangee);

		if (indiceRangee >= 0 && indiceRangee < this.getChildren().size()) {
			HBox ligne = (HBox) this.getChildren().get(indiceRangee);

			if (indiceColonne >= 0 && indiceColonne < ligne.getChildren().size()) {
				Case caseBouton = (Case) ligne.getChildren().get(indiceColonne);

				switch (forme) {
				case X:
					caseBouton.setText("X");
					break;

				case O:
					caseBouton.setText("O");
					break;
				}
			}
		}
	}
}
