package tic_tac_toe.pages.partie.modeles;

public interface PartieReseauLectureSeule 
       extends   PartieLectureSeule {

}
