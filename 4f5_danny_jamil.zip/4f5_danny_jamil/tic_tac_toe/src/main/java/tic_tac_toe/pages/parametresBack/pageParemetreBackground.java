package tic_tac_toe.pages.parametresBack;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ntro.debogage.DoitEtre;
import ntro.debogage.Erreur;
import ntro.debogage.J;
import ntro.javafx.ChargeurDeVue;
import ntro.javafx.Initialisateur;
import ntro.mvc.controleurs.FabriqueControleur;
import ntro.mvc.modeles.EntrepotDeModeles;
import ntro.systeme.Systeme;
import tic_tac_toe.client.MonClientWebSocket;

import static tic_tac_toe.Constantes.*;
import static tic_tac_toe.Constantes.ADRESSE_SERVEUR;


import java.net.URI;
import java.net.URISyntaxException;


public class pageParemetreBackground extends Application {

	static {

		Initialisateur.initialiser();
		
		J.appel(pageParemetreBackground.class);
	}
	
	public static void main(String[] args) {
		J.appel(pageParemetreBackground.class);
		launch(args);
	}

	@Override
	public void start(Stage fenetrePrincipale) throws Exception {
		J.appel(this);
		
		connecterAuServeur();
		
		ChargeurDeVue<VueParametresBack> chargeur;
		chargeur = new ChargeurDeVue<VueParametresBack>(CHEMIN_PARAMETRES_BACK_FXML, CHEMIN_PRINCIPAL_BACK_CSS, CHEMIN_CHAINES);

		VueParametresBack vue = chargeur.getVue();
		
		ParametresBack parametres = EntrepotDeModeles.creerModele(ParametresBack.class, ID_MODELE_PAR_DEFAUT);
		
		AfficheurParametresBack afficheurParametres = new AfficheurParametresBack();
		
		DoitEtre.nonNul(vue);

		FabriqueControleur.creerControleur(ControleurParametresBack.class, parametres, vue, afficheurParametres);

		Scene scene = chargeur.nouvelleScene(LARGEUR_PIXELS, HAUTEUR_PIXELS);

		fenetrePrincipale.setScene(scene);
		
		fenetrePrincipale.setMinWidth(LARGEUR_PIXELS);
		fenetrePrincipale.setMinHeight(HAUTEUR_PIXELS);
		
		capterEvenementFermeture(fenetrePrincipale);

		fenetrePrincipale.show();
	}

	private void capterEvenementFermeture(Stage fenetrePrincipale) {
		J.appel(this);

		fenetrePrincipale.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				J.appel(this);

				Systeme.quitter();
			}
		});
	}
	private void connecterAuServeur() {
		J.appel(this);

		URI uriServeur = null;
		
		try {

			uriServeur = new URI(ADRESSE_SERVEUR);

		} catch (URISyntaxException e) {
			
			Erreur.fatale("L'adresse du serveur est mal formée: " + ADRESSE_SERVEUR, e);
		}

		connecterAuServeur(uriServeur);
	}

	private void connecterAuServeur(URI uriServeur) {
		J.appel(this);

		MonClientWebSocket clientWebSocket = new MonClientWebSocket(uriServeur);
		
		Erreur.avertissement("Tentative de connexion au serveur... ");
		
		try {

			clientWebSocket.connectBlocking();

		} catch (InterruptedException e) {
			
			Erreur.nonFatale("Tentative de connexion annulée", e);
		}
	}
}
