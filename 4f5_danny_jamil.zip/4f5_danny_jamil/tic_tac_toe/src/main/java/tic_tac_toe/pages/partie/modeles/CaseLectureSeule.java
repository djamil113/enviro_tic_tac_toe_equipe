package tic_tac_toe.pages.partie.modeles;

import tic_tac_toe.enumerations.Forme;

public interface CaseLectureSeule {

	Forme getForme();
	int getIndiceRangee();
	int getIndiceColonne();

}
