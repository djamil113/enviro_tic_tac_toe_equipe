package tic_tac_toe.pages.accueil;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.VBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import ntro.commandes.FabriqueCommande;
import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.javafx.ChargeurDeVue;
import ntro.mvc.Vue;
import tic_tac_toe.commandes.nouvelle_partie.NouvellePartieLocale;
import tic_tac_toe.commandes.nouvelle_partie.NouvellePartieLocalePourEnvoi;
import tic_tac_toe.commandes.ouvrir_parametres.OuvrirParametres;
import tic_tac_toe.commandes.ouvrir_parametres.OuvrirParametresPourEnvoi;
import tic_tac_toe.commandes.ouvrir_parametresBack.OuvrirParametresBack;
import tic_tac_toe.commandes.ouvrir_parametresBack.OuvrirParametresBackPourEnvoi;
import tic_tac_toe.commandes.ouvrir_partieRecente.OuvrirPartieRecente;
import tic_tac_toe.commandes.ouvrir_partieRecente.OuvrirPartieRecentePourEnvoi;
import tic_tac_toe.commandes.quitter.Quitter;
import tic_tac_toe.commandes.quitter.QuitterPourEnvoi;
import tic_tac_toe.pages.partie.vues.VuePartieLocale;

import static tic_tac_toe.Constantes.*;

public class VueAccueil implements Vue, Initializable {
	
	@FXML
	private MenuItem menuNouvellePartieLocale, menuNouvellePartieReseau, menuParametres, menuParametresBack, menuPartieRecente, menuQuitter;
	
	@FXML
	private VBox conteneurPartie;
	
	private NouvellePartieLocalePourEnvoi nouvellePartieLocalePourEnvoi;
	private OuvrirParametresPourEnvoi ouvrirParametresPourEnvoi;
	private OuvrirParametresBackPourEnvoi ouvrirParametresBackPourEnvoi;
	private OuvrirPartieRecentePourEnvoi ouvrirPartieRecentePourEnvoi;
	private QuitterPourEnvoi quitterPourEnvoi;
	
	private String messageAlerteConnexion;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		J.appel(this);
		
		DoitEtre.nonNul(menuNouvellePartieLocale);
		DoitEtre.nonNul(menuParametres);
		DoitEtre.nonNul(menuParametresBack);
		DoitEtre.nonNul(menuPartieRecente);
		DoitEtre.nonNul(menuQuitter);
		
		messageAlerteConnexion = "Aucune connexion au serveur";
	}

	@Override
	public void obtenirCommandesPourEnvoi() {
		J.appel(this);
		
		nouvellePartieLocalePourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(NouvellePartieLocale.class);
		ouvrirParametresPourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(OuvrirParametres.class);
		ouvrirParametresBackPourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(OuvrirParametresBack.class);
		ouvrirPartieRecentePourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(OuvrirPartieRecente.class);
		quitterPourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(Quitter.class);
	}

	@Override
	public void installerCapteursEvenementsUsager() {
		J.appel(this);

		menuNouvellePartieLocale.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				nouvellePartieLocalePourEnvoi.envoyerCommande();
			}
		});

		menuParametres.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				ouvrirParametresPourEnvoi.envoyerCommande();
			}
		});
		
		menuParametresBack.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				ouvrirParametresBackPourEnvoi.envoyerCommande();
			}
		});
		
		menuPartieRecente.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				ouvrirPartieRecentePourEnvoi.envoyerCommande();
			}
		});
		
		menuQuitter.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);
				
				quitterPourEnvoi.envoyerCommande();
			}
		});
	}

	@Override
	public void verifierCommandesPossibles() {
		J.appel(this);
	}

	public VuePartieLocale creerVuePartieLocale() {
		J.appel(this);

		ChargeurDeVue<VuePartieLocale> chargeur;
		chargeur = new ChargeurDeVue<VuePartieLocale>(CHEMIN_PARTIE_LOCALE_FXML);

		VuePartieLocale vuePartieLocale = chargeur.getVue();
		
		Parent parent = chargeur.getParent();
		
		conteneurPartie.getChildren().clear();
		conteneurPartie.getChildren().add(parent);
		
		return vuePartieLocale;
	}

	public void alerterErreurConnexion() {
		J.appel(this);

		new Alert(AlertType.ERROR, messageAlerteConnexion).show();
	}

}
