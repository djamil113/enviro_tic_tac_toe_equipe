package tic_tac_toe.pages.parametresBack;

import ntro.mvc.modeles.ModeleLectureSeule;
import tic_tac_toe.enumerations.Couleurs;


public interface ParametresLectureSeule extends ModeleLectureSeule {
	
	Couleurs getColorBackground();
	Couleurs getColorForm(); 
	Couleurs getColorBorder();
}
