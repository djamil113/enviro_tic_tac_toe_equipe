package tic_tac_toe.pages.partie.modeles;

import java.util.List;

public interface GrilleLectureSeule {

	List<ColonneLectureSeule> getColonnes();
}
