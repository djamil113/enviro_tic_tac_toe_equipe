package tic_tac_toe.pages.partie.afficheurs;

import tic_tac_toe.pages.partie.modeles.PartieLocaleLectureSeule;
import tic_tac_toe.pages.partie.vues.VuePartieLocale;

public class AfficheurPartieLocale extends AfficheurPartie<PartieLocaleLectureSeule, VuePartieLocale> {

}