package tic_tac_toe.pages.partierecente;



import ntro.mvc.modeles.ModeleLectureSeule;
import tic_tac_toe.enumerations.Winner;
import tic_tac_toe.enumerations.numPartie;

public interface PartieRecenteLectureSeule extends ModeleLectureSeule {
	
		String getQuiGagne();
		 String getNumPartie();
		 
		 
		 
}
