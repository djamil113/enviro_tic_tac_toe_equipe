package tic_tac_toe.pages.partierecente;



import ntro.mvc.modeles.ModeleLectureSeule;

public interface PartieRecenteLectureSeule extends ModeleLectureSeule {
	
		String getQuiGagne();
		 String getNumPartie();
		 
		 
		 
}
