package tic_tac_toe.pages.partie.vues;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import ntro.commandes.FabriqueCommande;
import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.Vue;
import tic_tac_toe.Constantes;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.commandes.jouer_ici.JouerIci;
import tic_tac_toe.commandes.jouer_ici.JouerIciPourEnvoi;

public abstract class VuePartie implements Vue, Initializable {

	@FXML
	private VBox conteneurGrille;

	private Button[][] cases;

	private JouerIciPourEnvoi jouerIciPourEnvoi;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		J.appel(this);

		DoitEtre.nonNul(conteneurGrille);
	}

	public void creerGrille(int largeur, int hauteur) {
		J.appel(this);

		creerColonnes(largeur, hauteur);
	}

	private void creerColonnes(int largeur, int hauteur) {
		J.appel(this);

		cases = new Button[largeur][hauteur];

		for (int indiceRangee = 0; indiceRangee < hauteur; indiceRangee++) {
			HBox ligne = creerLigne(indiceRangee, largeur);

			conteneurGrille.getChildren().add(ligne);
		}
	}

	private HBox creerLigne(int indiceRangee, int largeur) {
		J.appel(this);

		HBox ligne = new HBox();

		for (int indiceColonne = 0; indiceColonne < largeur; indiceColonne++) {

			Button _case = new Button();

			_case.setMinWidth(Constantes.TAILLE_CASE);
			_case.setMaxWidth(Constantes.TAILLE_CASE);

			cases[indiceColonne][indiceRangee] = _case;

			ligne.getChildren().add(_case);
		}

		return ligne;
	}

	@Override
	public void obtenirCommandesPourEnvoi() {
		J.appel(this);

		jouerIciPourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(JouerIci.class);
	}

	@Override
	public void installerCapteursEvenementsUsager() {
		J.appel(this);

		for (int i = 0; i < cases.length; i++) {
			for (int j = 0; j < cases[i].length; j++) {

				final int indiceColonne = i;
				final int indiceRangee = j;

				cases[i][j].setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						J.appel(this);

						J.valeurs(indiceColonne);
						J.valeurs(indiceRangee);
						jouerIciPourEnvoi.setIndiceColonne(indiceColonne);
						jouerIciPourEnvoi.setIndiceRangee(indiceRangee);
						jouerIciPourEnvoi.envoyerCommande();
					}
				});
			}
		}
	}

	@Override
	public void verifierCommandesPossibles() {
		J.appel(this);
	}

	private boolean siIndicesValides(int indiceColonne, int indiceRangee) {
		J.appel(this);

		boolean siValide = false;

		if (indiceColonne >= 0 && indiceColonne < cases.length) {
			siValide = indiceRangee >= 0 && indiceRangee < cases[indiceColonne].length;
		}

		return siValide;
	}

	public void afficherCase(int indiceColonne, int indiceRangee, Forme forme) {
		J.appel(this);

		if (siIndicesValides(indiceColonne, indiceRangee)) {

			Button _case = cases[indiceColonne][indiceRangee];

			switch (forme) {
			case X:
				_case.setText("X");
				break;

			case O:
				_case.setText("O");
				break;
			}
		}
	}

}
