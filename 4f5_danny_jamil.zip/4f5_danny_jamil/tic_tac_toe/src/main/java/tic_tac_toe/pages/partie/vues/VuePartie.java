package tic_tac_toe.pages.partie.vues;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.Vue;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.pages.partie.composants.ConteneurCase;

public abstract class VuePartie implements Vue, Initializable {

	@FXML
	private ConteneurCase conteneurCase;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		J.appel(this);

		DoitEtre.nonNul(conteneurCase);
	}

	public void creerGrille(int largeur, int hauteur) {
		J.appel(this);

		conteneurCase.creerCases(largeur, hauteur);
	}

	@Override
	public void obtenirCommandesPourEnvoi() {
		J.appel(this);

		conteneurCase.obtenirJouerIciPourEnvoi();
	}

	@Override
	public void installerCapteursEvenementsUsager() {
		J.appel(this);

		conteneurCase.installerCapteursJouerIci();

	}

	@Override
	public void verifierCommandesPossibles() {
		J.appel(this);
	}

	public void afficherCase(int indiceColonne, int indiceRangee, Forme forme) {
		J.appel(this);

		conteneurCase.afficherCase(indiceColonne, indiceRangee, forme);
	}
}
