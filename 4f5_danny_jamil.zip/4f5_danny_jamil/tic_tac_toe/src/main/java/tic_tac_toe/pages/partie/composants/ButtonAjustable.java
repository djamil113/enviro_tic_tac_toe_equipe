package tic_tac_toe.pages.partie.composants;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.NamedArg;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.util.Duration;
import ntro.debogage.J;
import ntro.javafx.composants.CanvasAjustable;
import tic_tac_toe.enumerations.Couleurs;



public class ButtonAjustable extends CanvasAjustable {
	
	  private final double TAILLE_POURCENTAGE = 0.6;

	private Color couleurs;
	
	 
	    private Timeline animationEntreButton;
	

	public ButtonAjustable(@NamedArg("couleurs") Color couleurs) {
		super();
		J.appel(this);

		this.couleurs = couleurs;
		
	      creerAnimationEntreeJeton();
	        
		initialiserPinceau();
		dessinerCase();

	}

	public void afficherCouleur(Couleurs couleur) {
		J.appel(this);

		switch (couleur) {

		case JAUNE:
			pinceau.setFill(couleurs);
			 dessinerCase();
			break;

		case BLACK:
			pinceau.setFill(couleurs);
			  dessinerCase();
			break;

		case VERT:
			pinceau.setFill(couleurs);
			  dessinerCase();
			break;
		}
	}
	 private void initialiserPinceau() {
	        J.appel(this);

	        pinceau.setFill(Color.WHITE);
	        pinceau.setStroke(Color.BLACK);
	        pinceau.setLineWidth(0.01*getWidth());
	    }
	    private void viderDessin() {
	        J.appel(this);

	        pinceau.clearRect(0, 0, getWidth(), getHeight());
	    }
	 
	 private void dessinerCase() {
	        J.appel(this);
	        
	        dessinerCase(TAILLE_POURCENTAGE);
	    }
	
	 private class Case {
	        public double caseHautGaucheX;
	        public double caseHautGaucheY;
	        public double tailleCase;
	    }
	 
	 private void dessinerCase(double taillePourcentage) {
	        J.appel(this);
	        
	        Case laCase = calculerCase(taillePourcentage);
	        
	        dessinerFond(laCase);
	        dessinerContour(laCase);
	    }
	 
	  private void dessinerFond(Case laCase) {
	        J.appel(this);

	        pinceau.fillArc(laCase.caseHautGaucheX, 
	                        laCase.caseHautGaucheY, 
	                        laCase.tailleCase, 
	                        laCase.tailleCase, 
	                        0, 
	                        360, 
	                        ArcType.ROUND);
	    }
	  private void dessinerContour(Case laCase) {
	        J.appel(this);

	        pinceau.strokeArc(laCase.caseHautGaucheX, 
	                          laCase.caseHautGaucheY, 
	                          laCase.tailleCase, 
	                          laCase.tailleCase, 
	                          0, 
	                          360, 
	                          ArcType.OPEN);
	    }

	@Override
	protected void reagirHauteurInitiale(double arg0) {
		 J.appel(this);
		 
		viderDessin();
		dessinerCase();
	}

	@Override
	protected void reagirLargeurInitiale(double arg0) {
		 J.appel(this);
		 
		viderDessin();
		dessinerCase();
	}

	@Override
	protected void reagirNouvelleHauteur(double arg0, double arg1) {
		 J.appel(this);
		 
		viderDessin();
		dessinerCase();
	}

	@Override
	protected void reagirNouvelleLargeur(double arg0, double arg1) {
		 J.appel(this);
		 
		viderDessin();
		dessinerCase();
	}
	  private Case calculerCase(double taillePourcentage) {
	        J.appel(this);
	        
	        Case laCase = new Case();

	        double largeurDessin = getWidth();
	        double hauteurDessin = getHeight();
	        
	        laCase.tailleCase = largeurDessin * taillePourcentage;

	        if(hauteurDessin < largeurDessin) {
	            laCase.tailleCase = hauteurDessin * taillePourcentage;
	        }
	        
	        laCase.caseHautGaucheX = (largeurDessin - laCase.tailleCase) / 2;
	        laCase.caseHautGaucheY = (hauteurDessin - laCase.tailleCase) / 2;
	        
	        return laCase;
	    }
	  public void animerEntreeJeton() {
	        J.appel(this);
	        
	        animationEntreButton.playFromStart();
	    }

	  
	    private void creerAnimationEntreeJeton() {
	        J.appel(this);
	        
	        animationEntreButton= new Timeline();

	        animationEntreButton.getKeyFrames().add(
	                new KeyFrame(Duration.ZERO,
	                             new KeyValue(this.translateYProperty(), -100),
	                             new KeyValue(this.opacityProperty(), 0)));

	        animationEntreButton.getKeyFrames().add(
	                new KeyFrame(new Duration(100),
	                             new KeyValue(this.translateYProperty(), 0),
	                             new KeyValue(this.opacityProperty(), 1))); 
	    }


}
