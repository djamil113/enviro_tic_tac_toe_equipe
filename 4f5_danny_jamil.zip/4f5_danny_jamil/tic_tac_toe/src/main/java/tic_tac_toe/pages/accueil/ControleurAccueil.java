package tic_tac_toe.pages.accueil;

import ntro.debogage.Erreur;
import ntro.debogage.J;
import ntro.systeme.Systeme;
import ntro.javafx.ChargeurDeVue;
import ntro.javafx.DialogueModal;
import ntro.messages.FabriqueMessage;
import ntro.messages.RecepteurMessage;
import ntro.mvc.controleurs.ControleurVue;
import ntro.mvc.controleurs.FabriqueControleur;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import ntro.mvc.modeles.EntrepotDeModeles;
import javafx.scene.Scene;
import javafx.stage.Stage;
import tic_tac_toe.client.MonClient;
import tic_tac_toe.commandes.fermer_parametres.FermerParametres;
import tic_tac_toe.commandes.fermer_parametres.FermerParametresRecue;
import tic_tac_toe.commandes.fermer_parametresBack.FermerParametresBack;
import tic_tac_toe.commandes.fermer_parametresBack.FermerParametresBackRecue;
import tic_tac_toe.commandes.nouvelle_partie.NouvellePartieLocale;
import tic_tac_toe.commandes.nouvelle_partie.NouvellePartieLocaleRecue;
import tic_tac_toe.commandes.nouvelle_partie_reseau.NouvellePartieReseau;
import tic_tac_toe.commandes.nouvelle_partie_reseau.NouvellePartieReseauRecue;
import tic_tac_toe.commandes.ouvrir_parametres.OuvrirParametres;
import tic_tac_toe.commandes.ouvrir_parametres.OuvrirParametresRecue;
import tic_tac_toe.commandes.ouvrir_parametresBack.OuvrirParametresBack;
import tic_tac_toe.commandes.ouvrir_parametresBack.OuvrirParametresBackRecue;
import tic_tac_toe.commandes.ouvrir_partieRecente.OuvrirPartieRecente;
import tic_tac_toe.commandes.ouvrir_partieRecente.OuvrirPartieRecenteRecue;
import tic_tac_toe.commandes.quitter.Quitter;
import tic_tac_toe.commandes.quitter.QuitterRecue;
import tic_tac_toe.messages.nouvelle_partie_reseau.MsgNouvellePartie;
import tic_tac_toe.messages.nouvelle_partie_reseau.MsgNouvellePartiePourEnvoi;
import tic_tac_toe.messages.nouvelle_partie_reseau.MsgNouvellePartieRecu;
import tic_tac_toe.pages.parametres.AfficheurParametres;
import tic_tac_toe.pages.parametres.ControleurParametres;
import tic_tac_toe.pages.parametres.Parametres;
import tic_tac_toe.pages.parametres.VueParametres;
import tic_tac_toe.pages.parametresBack.AfficheurParametresBack;
import tic_tac_toe.pages.parametresBack.ControleurParametresBack;
import tic_tac_toe.pages.parametresBack.ParametresBack;
import tic_tac_toe.pages.parametresBack.VueParametresBack;
import tic_tac_toe.pages.partie.afficheurs.AfficheurPartieLocale;
import tic_tac_toe.pages.partie.controleurs.ControleurPartieLocale;
import tic_tac_toe.pages.partie.modeles.PartieLocale;
import tic_tac_toe.pages.partie.vues.VuePartieLocale;
import tic_tac_toe.pages.partierecente.AfficheurPartieRecente;
import tic_tac_toe.pages.partierecente.ControleurPartieRecente;
import tic_tac_toe.pages.partierecente.VuePartieRecente;
import tic_tac_toe.pages.partierecente.partieRecent;
import tic_tac_toe.pages.partie.afficheurs.AfficheurPartieReseau;
import tic_tac_toe.pages.partie.controleurs.ControleurPartieReseau;
import tic_tac_toe.pages.partie.modeles.PartieReseau;
import tic_tac_toe.pages.partie.vues.VuePartieReseau;

import static tic_tac_toe.Constantes.*;

import java.io.IOException;

public class ControleurAccueil extends ControleurVue<VueAccueil> {

	private Scene sceneParametres;
	private Scene sceneParametresBack;
	private Scene scenePartieRecente;
	private Stage dialogueParametres;
	private Stage dialogueParametresBack;
	private Stage dialoguePartieRecente;
	private Parametres parametres;
	private ParametresBack parametresBack;
	private partieRecent partieRecente;
	private PartieLocale partieLocale;
	private MsgNouvellePartiePourEnvoi messageNouvellePartieReseau;

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);

		installerRecepteurCommande(NouvellePartieLocale.class, new RecepteurCommandeMVC<NouvellePartieLocaleRecue>() {
			@Override
			public void executerCommandeMVC(NouvellePartieLocaleRecue commande) {
				J.appel(this);

				nouvellePartieLocale();
			}
		});

		installerRecepteurCommande(NouvellePartieReseau.class, new RecepteurCommandeMVC<NouvellePartieReseauRecue>() {
			@Override
			public void executerCommandeMVC(NouvellePartieReseauRecue commande) {
				J.appel(this);

				initierNouvellePartieReseau();
			}
		});

		installerRecepteurCommande(OuvrirParametres.class, new RecepteurCommandeMVC<OuvrirParametresRecue>() {
			@Override
			public void executerCommandeMVC(OuvrirParametresRecue commande) {
				J.appel(this);

				ouvrirParametres();
			}
		});

		installerRecepteurCommande(FermerParametres.class, new RecepteurCommandeMVC<FermerParametresRecue>() {
			@Override
			public void executerCommandeMVC(FermerParametresRecue commande) {
				J.appel(this);

				fermerParametres();
			}
		});

		installerRecepteurCommande(OuvrirParametresBack.class, new RecepteurCommandeMVC<OuvrirParametresBackRecue>() {
			@Override
			public void executerCommandeMVC(OuvrirParametresBackRecue commande) {
				J.appel(this);

				ouvrirParametresBack();
			}
		});

		installerRecepteurCommande(FermerParametresBack.class, new RecepteurCommandeMVC<FermerParametresBackRecue>() {
			@Override
			public void executerCommandeMVC(FermerParametresBackRecue commande) {
				J.appel(this);

				fermerParametresBack();
			}
		});

		installerRecepteurCommande(OuvrirPartieRecente.class, new RecepteurCommandeMVC<OuvrirPartieRecenteRecue>() {
			@Override
			public void executerCommandeMVC(OuvrirPartieRecenteRecue commande) {
				J.appel(this);

				ouvrirPartieRecente();
			}
		});

		installerRecepteurCommande(Quitter.class, new RecepteurCommandeMVC<QuitterRecue>() {
			@Override
			public void executerCommandeMVC(QuitterRecue commande) {
				J.appel(this);

				quitter();
			}
		});
	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);

		messageNouvellePartieReseau = FabriqueMessage.obtenirMessagePourEnvoi(MsgNouvellePartie.class);
	}

	@Override
	protected void installerReceptionMessages() {
		J.appel(this);

		FabriqueMessage.installerRecepteur(MsgNouvellePartie.class, new RecepteurMessage<MsgNouvellePartieRecu>() {

			@Override
			public void recevoirMessage(MsgNouvellePartieRecu messageRecu) {
				J.appel(this);

				creerNouvellePartieReseau(messageRecu.getParametres());
			}
		});
	}

	@Override
	protected void demarrer() {
		J.appel(this);

		instancierControleurParametres();
		instancierControleurParametresBack();
		instancierControleurPartieRecente();

		ouvrirPartieLocale();
	}

	private void instancierControleurParametres() {
		J.appel(this);

		ChargeurDeVue<VueParametres> chargeur;
		chargeur = new ChargeurDeVue<VueParametres>(CHEMIN_PARAMETRES_FXML, CHEMIN_PARAMETRES_CSS, CHEMIN_CHAINES);

		sceneParametres = chargeur.nouvelleScene(LARGEUR_PARAMETRES_PIXELS, HAUTEUR_PARAMETRES_PIXELS);

		parametres = EntrepotDeModeles.creerModele(Parametres.class, ID_MODELE_PAR_DEFAUT);

		AfficheurParametres afficheurParametres = new AfficheurParametres();

		VueParametres vueParametres = chargeur.getVue();

		FabriqueControleur.creerControleur(ControleurParametres.class, parametres, vueParametres, afficheurParametres);
	}

	private void instancierControleurParametresBack() {
		J.appel(this);

		ChargeurDeVue<VueParametresBack> chargeur;
		chargeur = new ChargeurDeVue<VueParametresBack>(CHEMIN_PARAMETRES_BACK_FXML, CHEMIN_PRINCIPAL_BACK_CSS, CHEMIN_CHAINES);

		sceneParametresBack = chargeur.nouvelleScene(LARGEUR_PIXELS, HAUTEUR_PIXELS);

		parametresBack = EntrepotDeModeles.creerModele(ParametresBack.class, ID_MODELE_PAR_DEFAUT);

		AfficheurParametresBack afficheurParametresBack = new AfficheurParametresBack();

		VueParametresBack vueParametresBack = chargeur.getVue();

		FabriqueControleur.creerControleur(ControleurParametresBack.class, parametresBack, vueParametresBack,
				afficheurParametresBack);
	}

	private void instancierControleurPartieRecente() {
		J.appel(this);

		ChargeurDeVue<VuePartieRecente> chargeur;
		chargeur = new ChargeurDeVue<VuePartieRecente>(CHEMIN_PARTIERECENTE_FXML, CHEMIN_PARTIERECENTE_CSS, CHEMIN_CHAINES);

		scenePartieRecente = chargeur.nouvelleScene(LARGEUR_PARAMETRES_PIXELS, HAUTEUR_PARAMETRES_PIXELS);

		partieRecente = EntrepotDeModeles.creerModele(partieRecent.class, ID_MODELE_PAR_DEFAUT);

		AfficheurPartieRecente afficheurPartieRecente = new AfficheurPartieRecente();

		VuePartieRecente vuePartieRecente = chargeur.getVue();

		FabriqueControleur.creerControleur(ControleurPartieRecente.class, partieRecente, vuePartieRecente,
				afficheurPartieRecente);
	}

	private void ouvrirPartieLocale() {
		J.appel(this);

		try {

			partieLocale = EntrepotDeModeles.obtenirModele(PartieLocale.class, ID_MODELE_PAR_DEFAUT);

		} catch (IOException e) {

			creerNouvellePartieLocaleSelonParametres(parametres);
		}

		instancierControleurPartieLocale();
	}

	private void nouvellePartieLocale() {
		J.appel(this);

		creerNouvellePartieLocaleSelonParametres(parametres);

		instancierControleurPartieLocale();
	}

	private void instancierControleurPartieLocale() {
		J.appel(this);

		VuePartieLocale vuePartieLocale = getVue().creerVuePartieLocale();

		AfficheurPartieLocale afficheur = new AfficheurPartieLocale();

		FabriqueControleur.creerControleur(ControleurPartieLocale.class, partieLocale, vuePartieLocale, afficheur);
	}

	private void creerNouvellePartieLocaleSelonParametres(Parametres parametres) {
		J.appel(this);

		partieLocale = EntrepotDeModeles.creerModele(PartieLocale.class, ID_MODELE_PAR_DEFAUT);
		partieLocale.setFormeCourante(parametres.getQuiCommence());
		partieLocale.setLargeur(parametres.getTailleGrille().getLargeur());
		partieLocale.setHauteur(parametres.getTailleGrille().getHauteur());
	}

	private void ouvrirParametres() {
		J.appel(this);

		dialogueParametres = DialogueModal.ouvrirDialogueModal(sceneParametres);

		dialogueParametres.setMinWidth(LARGEUR_PARAMETRES_PIXELS_MIN);
		dialogueParametres.setMinHeight(HAUTEUR_PARAMETRES_PIXELS_MIN);

		dialogueParametres.setWidth(LARGEUR_PARAMETRES_PIXELS);
		dialogueParametres.setHeight(HAUTEUR_PARAMETRES_PIXELS);

		dialogueParametres.setMaxWidth(LARGEUR_PARAMETRES_PIXELS_MAX);
		dialogueParametres.setMaxHeight(HAUTEUR_PARAMETRES_PIXELS_MAX);
	}

	private void fermerParametres() {
		J.appel(this);

		if (dialogueParametres != null) {
			dialogueParametres.close();
		}
	}

	private void ouvrirParametresBack() {
		J.appel(this);

		dialogueParametresBack = DialogueModal.ouvrirDialogueModal(sceneParametresBack);

		dialogueParametresBack.setMinWidth(LARGEUR_PARAMETRES_PIXELS_MIN);
		dialogueParametresBack.setMinHeight(HAUTEUR_PARAMETRES_PIXELS_MIN);

		dialogueParametresBack.setWidth(LARGEUR_PARAMETRES_PIXELS);
		dialogueParametresBack.setHeight(HAUTEUR_PARAMETRES_PIXELS);

		dialogueParametresBack.setMaxWidth(LARGEUR_PARAMETRES_PIXELS_MAX);
		dialogueParametresBack.setMaxHeight(HAUTEUR_PARAMETRES_PIXELS_MAX);
	}

	private void fermerParametresBack() {
		J.appel(this);

		if (dialogueParametresBack != null) {
			dialogueParametresBack.close();
		}
	}

	private void ouvrirPartieRecente() {
		J.appel(this);

		dialoguePartieRecente = DialogueModal.ouvrirDialogueModal(scenePartieRecente);

		dialoguePartieRecente.setMinWidth(LARGEUR_PARAMETRES_PIXELS_MIN);
		dialoguePartieRecente.setMinHeight(HAUTEUR_PARAMETRES_PIXELS_MIN);

		dialoguePartieRecente.setWidth(LARGEUR_PARAMETRES_PIXELS);
		dialoguePartieRecente.setHeight(HAUTEUR_PARAMETRES_PIXELS);

		dialoguePartieRecente.setMaxWidth(LARGEUR_PARAMETRES_PIXELS_MAX);
		dialoguePartieRecente.setMaxHeight(HAUTEUR_PARAMETRES_PIXELS_MAX);
	}

	private void initierNouvellePartieReseau() {
		J.appel(this);

		if (MonClient.siConnecteAuServeur()) {

			messageNouvellePartieReseau.setParametres(parametres);
			messageNouvellePartieReseau.envoyerMessage();

			creerNouvellePartieReseau(parametres);

		} else {

			getVue().alerterErreurConnexion();
		}
	}

	private void creerNouvellePartieReseau(Parametres parametres) {
		J.appel(this);

		VuePartieReseau vuePartieReseau = getVue().creerVuePartieReseau();

		PartieReseau partie = creerPartieReseauSelonParametres(parametres);

		AfficheurPartieReseau afficheur = new AfficheurPartieReseau();

		FabriqueControleur.creerControleur(ControleurPartieReseau.class, partie, vuePartieReseau, afficheur);
	}

	private PartieReseau creerPartieReseauSelonParametres(Parametres parametres) {
		J.appel(this);

		PartieReseau partie = EntrepotDeModeles.creerModele(PartieReseau.class, ID_MODELE_PAR_DEFAUT);

		partie.setFormeCourante(parametres.getQuiCommence());
		partie.setHauteur(parametres.getTailleGrille().getHauteur());
		partie.setLargeur(parametres.getTailleGrille().getLargeur());
		return partie;
	}

	private void quitter() {
		J.appel(this);

		sauvegarderPartieLocale();

		Systeme.quitter();
	}

	private void sauvegarderPartieLocale() {
		J.appel(this);

		if (partieLocale != null) {
			try {

				EntrepotDeModeles.sauvegarderModele(partieLocale);

			} catch (IOException e) {

				Erreur.nonFatale("Impossible de sauvegarder la partie locale", e);
			}
		}
	}
}
