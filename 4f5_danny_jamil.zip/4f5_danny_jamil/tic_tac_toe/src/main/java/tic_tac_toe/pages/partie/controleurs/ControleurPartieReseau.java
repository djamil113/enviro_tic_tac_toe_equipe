package tic_tac_toe.pages.partie.controleurs;

import ntro.debogage.J;
import ntro.messages.FabriqueMessage;
import ntro.mvc.controleurs.RecepteurMessageMVC;
import tic_tac_toe.commandes.jouer_ici.JouerIciRecue;
import tic_tac_toe.pages.partie.afficheurs.AfficheurPartieReseau;
import tic_tac_toe.pages.partie.modeles.PartieReseau;
import tic_tac_toe.pages.partie.modeles.PartieReseauLectureSeule;
import tic_tac_toe.pages.partie.vues.VuePartieReseau;
import tic_tac_toe.messages.transmettre_coup.MsgTransmettreCoup;
import tic_tac_toe.messages.transmettre_coup.MsgTransmettreCoupPourEnvoi;
import tic_tac_toe.messages.transmettre_coup.MsgTransmettreCoupRecu;

public class ControleurPartieReseau

		extends ControleurPartie<PartieReseauLectureSeule, PartieReseau, VuePartieReseau, AfficheurPartieReseau> {

	private MsgTransmettreCoupPourEnvoi transmettreCoup;

	@Override
	protected void obtenirMessagesPourEnvoi() {
		super.obtenirMessagesPourEnvoi();
		J.appel(this);

		transmettreCoup = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreCoup.class);
	}

	@Override
	protected void installerReceptionMessages() {
		super.installerReceptionMessages();
		J.appel(this);

		installerRecepteurMessage(MsgTransmettreCoup.class, new RecepteurMessageMVC<MsgTransmettreCoupRecu>() {

			@Override
			public void recevoirMessageMVC(MsgTransmettreCoupRecu messageRecu) {
				J.appel(this);

				getModele().jouerIci(messageRecu.getIndiceColonne(), messageRecu.getIndiceRangee());
			}
		});
	}

	@Override
	protected void reagirCommandeJouerIci(JouerIciRecue jouerIciRecue) {
		super.reagirCommandeJouerIci(jouerIciRecue);
		J.appel(this);

		transmettreCoup.setIndiceColonne(jouerIciRecue.getIndiceColonne());
		transmettreCoup.setIndiceRangee(jouerIciRecue.getIndiceRangee());
		transmettreCoup.envoyerMessage();
	}
}
