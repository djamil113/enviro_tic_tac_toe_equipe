package tic_tac_toe.pages.partierecente;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.modeles.Modele;
import tic_tac_toe.enumerations.Winner;
import tic_tac_toe.enumerations.numPartie;

public class partieRecent extends Modele<PartieRecenteLectureSeule> implements PartieRecenteLectureSeule {

	private String quiGagne;
	private  String nPartie;



	@Override
	public void apresCreation() {
		J.appel(this);
		
		quiGagne = Winner.JOUEUR1.toString();
		nPartie = numPartie.PARTIE1.toString(); 	
		
	}
	
	@Override
	public void apresChargementJson() {
		J.appel(this);
		
		DoitEtre.nonNul(quiGagne);
		DoitEtre.nonNul(nPartie);
		
	}
	
	@Override
	public  String getQuiGagne() {
		J.appel(this);
		
		return quiGagne;
	}
	
	public void DefinirQuiGagne(String quiGagne) {
		J.appel(this);
		this.quiGagne = quiGagne;
	}
	
	public void DefinirNumeroPartie(String nuPartie) {
		J.appel(this);
		this.nPartie = nuPartie;
	}
	
	
	@Override
	public String getNumPartie() {
		// TODO Auto-generated method stub
		return nPartie;
	}
}