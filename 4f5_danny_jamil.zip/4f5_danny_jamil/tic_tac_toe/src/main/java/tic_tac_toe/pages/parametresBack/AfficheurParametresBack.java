package tic_tac_toe.pages.parametresBack;

import ntro.debogage.J;
import ntro.mvc.Afficheur;

public class   AfficheurParametresBack 
extends Afficheur<ParametresBackLectureSeule, VueParametresBack> {

	@Override
	public void initialiserAffichage(ParametresBackLectureSeule modeleLectureSeule, VueParametresBack vue) {
		J.appel(this);
		
	}

	@Override
	public void rafraichirAffichage(ParametresBackLectureSeule modeleLectureSeule, VueParametresBack vue) {
		J.appel(this);
		
	vue.afficheCouleurBordure(modeleLectureSeule.getColorBorder());
	vue.afficheCouleurForme(modeleLectureSeule.getColorForm());
		
	}

}
