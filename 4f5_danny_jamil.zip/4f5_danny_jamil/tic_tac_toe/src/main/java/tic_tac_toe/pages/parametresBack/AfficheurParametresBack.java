package tic_tac_toe.pages.parametresBack;

import ntro.debogage.J;
import ntro.mvc.Afficheur;


public class   AfficheurParametresBack 
extends Afficheur<ParametresLectureSeule, VueParametresBack> {

	@Override
	public void initialiserAffichage(ParametresLectureSeule modeleLectureSeule, VueParametresBack vue) {
		J.appel(this);
		
	}

	@Override
	public void rafraichirAffichage(ParametresLectureSeule modeleLectureSeule, VueParametresBack vue) {
		J.appel(this);
		
	vue.afficheCouleurBordure(modeleLectureSeule.getColorBorder());
	vue.afficheCouleurForme(modeleLectureSeule.getColorForm());
	vue.afficheCouleurBackground(modeleLectureSeule.getColorBackground());
	vue.animation();
		
	}

}
