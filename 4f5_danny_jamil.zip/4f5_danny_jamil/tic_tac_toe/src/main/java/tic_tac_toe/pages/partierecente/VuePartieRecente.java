package tic_tac_toe.pages.partierecente;

import java.awt.Button;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import ntro.commandes.FabriqueCommande;
import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.Vue;
import tic_tac_toe.commandes.definir_qui_gagne.DefinirQuiGagne;
import tic_tac_toe.commandes.numero_partie.NumeroPartie;
import tic_tac_toe.pages.partie.composants.Resultat;
import tic_tac_toe.enumerations.CouleursPartieRecent;

public class VuePartieRecente implements Vue, Initializable {

	@FXML
	private Text textWinner;

	@FXML
	private Text textNumPartie;
	
	@FXML
	private Resultat dessin;

	@FXML
	Button btnFermer;

	@FXML
	private javafx.scene.control.Button closeButton;

	@FXML
	private void closeButtonAction() {

		Stage fenetre = (Stage) closeButton.getScene().getWindow();

		fenetre.close();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		J.appel(this);

		DoitEtre.nonNul(dessin);
		DoitEtre.nonNul(textWinner);
		DoitEtre.nonNul(textNumPartie);
		
		dessin.afficherJeton(CouleursPartieRecent.BLACK);
		dessin.afficherJeton(CouleursPartieRecent.BLUE);
	}

	@Override
	public void installerCapteursEvenementsUsager() {
		J.appel(this);
	}
	
	public void animation() {
		dessin.animerEntreeJeton();
	}

	@Override
	public void obtenirCommandesPourEnvoi() {
		J.appel(this);

		FabriqueCommande.obtenirCommandePourEnvoi(DefinirQuiGagne.class);
		FabriqueCommande.obtenirCommandePourEnvoi(NumeroPartie.class);
	}

	@Override
	public void verifierCommandesPossibles() {
		J.appel(this);
	}

	public void afficherQuiGagne(String winner) {
		J.appel(this);

		DoitEtre.nonNul(winner);

		textWinner.setText(winner);
	}

	public void afficherNumPartie(String numPartie) {
		J.appel(this);
		DoitEtre.nonNul(numPartie);

		textNumPartie.setText(numPartie);
	}
}
