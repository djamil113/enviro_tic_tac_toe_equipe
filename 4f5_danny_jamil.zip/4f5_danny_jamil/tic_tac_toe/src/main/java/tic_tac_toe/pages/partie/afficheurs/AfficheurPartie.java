package tic_tac_toe.pages.partie.afficheurs;

import java.util.List;

import ntro.debogage.J;
import ntro.mvc.Afficheur;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.pages.partie.modeles.ColonneLectureSeule;
import tic_tac_toe.pages.partie.modeles.GrilleLectureSeule;
import tic_tac_toe.pages.partie.modeles.CaseLectureSeule;
import tic_tac_toe.pages.partie.modeles.PartieLectureSeule;
import tic_tac_toe.pages.partie.vues.VuePartie;

public abstract class AfficheurPartie<PLS extends PartieLectureSeule, V extends VuePartie>

		extends Afficheur<PLS, V> {

	@Override
	public void initialiserAffichage(PLS partieLectureSeule, V vue) {
		J.appel(this);

		int largeur = partieLectureSeule.getLargeur();
		int hauteur = partieLectureSeule.getHauteur();

		vue.creerGrille(largeur, hauteur);
	}

	@Override
	public void rafraichirAffichage(PLS partieLectureSeule, V vue) {
		J.appel(this);

		GrilleLectureSeule grille = partieLectureSeule.getGrille();

		int hauteurGrille = partieLectureSeule.getHauteur();

		rafraichirGrille(hauteurGrille, grille, vue);
	}

	private void rafraichirGrille(int hauteurGrille, GrilleLectureSeule grille, V vue) {
		J.appel(this);

		List<ColonneLectureSeule> colonnes = grille.getColonnes();

		for (int indiceColonne = 0; indiceColonne < colonnes.size(); indiceColonne++) {

			ColonneLectureSeule colonne = colonnes.get(indiceColonne);
			List<CaseLectureSeule> cases = colonne.getCases();

			rafraichirColonne(hauteurGrille, indiceColonne, cases, vue);

		}
	}

	private void rafraichirColonne(int hauteurGrille, int indiceColonne, List<CaseLectureSeule> cases, V vue) {
		J.appel(this);

		for (int indiceRangee = 0; indiceRangee < cases.size(); indiceRangee++) {

			CaseLectureSeule Case = cases.get(indiceRangee);
			// Chercher l'indice de la rangee sur la case et on va utiliser ca pour afficher
			int rang = Case.getIndiceRangee();
			Forme forme = Case.getForme();

			afficherCase(hauteurGrille, indiceColonne, rang, forme, vue);
		}
	}

	private void afficherCase(int hauteurGrille, int indiceColonne, int indiceRangee, Forme forme, V vue) {
		J.appel(this);

		vue.afficherCase(indiceColonne, indiceRangee, forme);
	}

}
