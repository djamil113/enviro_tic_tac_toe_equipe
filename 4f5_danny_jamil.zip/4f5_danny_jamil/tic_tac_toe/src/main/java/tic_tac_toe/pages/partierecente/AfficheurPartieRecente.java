package tic_tac_toe.pages.partierecente;

import ntro.debogage.J;
import ntro.mvc.Afficheur;


public class AfficheurPartieRecente extends Afficheur<PartieRecenteLectureSeule, VuePartieRecente>  {

	@Override
	public void initialiserAffichage(PartieRecenteLectureSeule modeleLectureSeule, VuePartieRecente vue) {
		J.appel(this);
		
	}

	@Override
	public void rafraichirAffichage(PartieRecenteLectureSeule modeleLectureSeule, VuePartieRecente vue) {
		J.appel(this);
		
		vue.afficherQuiGagne(modeleLectureSeule.getQuiGagne());
		vue.afficherNumPartie(modeleLectureSeule.getNumPartie());
		
		
	}

}
