package tic_tac_toe.pages.partie.controleurs;

import tic_tac_toe.pages.partie.afficheurs.AfficheurPartieLocale;
import tic_tac_toe.pages.partie.modeles.PartieLocale;
import tic_tac_toe.pages.partie.modeles.PartieLocaleLectureSeule;
import tic_tac_toe.pages.partie.vues.VuePartieLocale;

public class ControleurPartieLocale
        extends ControleurPartie<PartieLocaleLectureSeule, 
        						 PartieLocale, 
        						 VuePartieLocale, 
        						 AfficheurPartieLocale> {

}
