package tic_tac_toe.pages.partie.afficheurs;

import tic_tac_toe.pages.partie.modeles.PartieReseauLectureSeule;
import tic_tac_toe.pages.partie.vues.VuePartieReseau;

public class   AfficheurPartieReseau
	   extends AfficheurPartie<PartieReseauLectureSeule, VuePartieReseau>  {

}
