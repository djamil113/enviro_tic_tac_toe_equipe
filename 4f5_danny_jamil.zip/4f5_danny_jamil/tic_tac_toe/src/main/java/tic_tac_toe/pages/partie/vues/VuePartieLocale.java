package tic_tac_toe.pages.partie.vues;

public class VuePartieLocale extends VuePartie {
}
