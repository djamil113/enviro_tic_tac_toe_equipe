package tic_tac_toe.pages.parametres;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.messages.FabriqueMessage;
import ntro.mvc.controleurs.ControleurModeleVue;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import ntro.mvc.controleurs.RecepteurMessageMVC;
import tic_tac_toe.commandes.choisir_qui_commence.ChoisirQuiCommence;
import tic_tac_toe.commandes.choisir_qui_commence.ChoisirQuiCommenceRecue;
import tic_tac_toe.commandes.choisir_taille_grille.ChoisirTailleGrille;
import tic_tac_toe.commandes.choisir_taille_grille.ChoisirTailleGrilleRecue;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.enumerations.TailleGrille;
import tic_tac_toe.messages.transmettre_qui_commence.MsgTransmettreQuiCommence;
import tic_tac_toe.messages.transmettre_qui_commence.MsgTransmettreQuiCommencePourEnvoi;
import tic_tac_toe.messages.transmettre_qui_commence.MsgTransmettreQuiCommenceRecu;
import tic_tac_toe.messages.transmettre_taille.MsgTransmettreTaille;
import tic_tac_toe.messages.transmettre_taille.MsgTransmettreTaillePourEnvoi;
import tic_tac_toe.messages.transmettre_taille.MsgTransmettreTailleRecu;


public class ControleurParametres 
	   extends ControleurModeleVue<ParametresLectureSeule, 
	   							   Parametres, 
	   							   VueParametres, 
	   							   AfficheurParametres> {
	
	private MsgTransmettreQuiCommencePourEnvoi msgTransmettreQuiCommence;
	private MsgTransmettreTaillePourEnvoi msgTransmettreTaille;

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);
		
		installerRecepteurCommande(ChoisirQuiCommence.class, new RecepteurCommandeMVC<ChoisirQuiCommenceRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirQuiCommenceRecue commande) {
				J.appel(this);
				
				Forme quiCommence = commande.getForme();

				DoitEtre.nonNul(quiCommence);

				getModele().choisirQuiCommence(quiCommence);
				
				msgTransmettreQuiCommence.setQuiCommence(quiCommence);
				msgTransmettreQuiCommence.envoyerMessage();
			}
		});
		
		installerRecepteurCommande(ChoisirTailleGrille.class, new RecepteurCommandeMVC<ChoisirTailleGrilleRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirTailleGrilleRecue commande) {
				J.appel(this);
				
				TailleGrille tailleGrille = commande.getTailleGrille();
				
				DoitEtre.nonNul(tailleGrille);
				
				getModele().choisirTailleGrille(tailleGrille);
				
				msgTransmettreTaille.setTailleGrille(tailleGrille);
				msgTransmettreTaille.envoyerMessage();
			}
		});		
	}

	@Override
	protected void demarrer() {
		J.appel(this);
		
	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);
		
		msgTransmettreQuiCommence = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreQuiCommence.class);
		msgTransmettreTaille = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreTaille.class);
	}
	
	@Override
	protected void installerReceptionMessages() {
		J.appel(this);
		
		installerRecepteurMessage(MsgTransmettreQuiCommence.class, new RecepteurMessageMVC<MsgTransmettreQuiCommenceRecu>() {

			@Override
			public void recevoirMessageMVC(MsgTransmettreQuiCommenceRecu messageRecu) {
				J.appel(this);
				
				Forme quiCommence = messageRecu.getQuiCommence();
				
				DoitEtre.nonNul(quiCommence);
				
				getModele().choisirQuiCommence(quiCommence);
			}
		});
		
		installerRecepteurMessage(MsgTransmettreTaille.class, new RecepteurMessageMVC<MsgTransmettreTailleRecu>() {
			@Override
			public void recevoirMessageMVC(MsgTransmettreTailleRecu messageRecu) {
				J.appel(this);
				
				TailleGrille tailleGrille = messageRecu.getTailleGrille();
				
				DoitEtre.nonNul(tailleGrille);
				
				getModele().choisirTailleGrille(tailleGrille);
			}
		});
	}

}
