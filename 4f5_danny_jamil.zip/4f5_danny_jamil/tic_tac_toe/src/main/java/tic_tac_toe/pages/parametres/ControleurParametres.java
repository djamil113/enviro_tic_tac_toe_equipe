package tic_tac_toe.pages.parametres;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.controleurs.ControleurModeleVue;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import tic_tac_toe.commandes.choisir_qui_commence.ChoisirQuiCommence;
import tic_tac_toe.commandes.choisir_qui_commence.ChoisirQuiCommenceRecue;
import tic_tac_toe.commandes.choisir_taille_grille.ChoisirTailleGrille;
import tic_tac_toe.commandes.choisir_taille_grille.ChoisirTailleGrilleRecue;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.enumerations.TailleGrille;


public class ControleurParametres extends ControleurModeleVue<ParametresLectureSeule, Parametres, VueParametres, 
AfficheurParametres> {

	@Override
	protected void demarrer() {
		J.appel(this);
		
	}

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);
		
		installerRecepteurCommande(ChoisirQuiCommence.class, new RecepteurCommandeMVC<ChoisirQuiCommenceRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirQuiCommenceRecue commande) {
				J.appel(this);
				
				Forme quiCommence = commande.getForme();

				DoitEtre.nonNul(quiCommence);

				getModele().choisirQuiCommence(quiCommence);
			}
		});
		
		installerRecepteurCommande(ChoisirTailleGrille.class, new RecepteurCommandeMVC<ChoisirTailleGrilleRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirTailleGrilleRecue commande) {
				J.appel(this);
				
				TailleGrille tailleGrille = commande.getTailleGrille();
				
				DoitEtre.nonNul(tailleGrille);
				
				getModele().choisirTailleGrille(tailleGrille);
			}
		});		
	}

	@Override
	protected void installerReceptionMessages() {
		J.appel(this);
		
	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);
		
	}

}
