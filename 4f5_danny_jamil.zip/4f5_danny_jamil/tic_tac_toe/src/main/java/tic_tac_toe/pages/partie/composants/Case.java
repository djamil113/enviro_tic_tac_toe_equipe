package tic_tac_toe.pages.partie.composants;

import ntro.commandes.FabriqueCommande;
import ntro.debogage.J;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import tic_tac_toe.commandes.jouer_ici.JouerIci;
import tic_tac_toe.commandes.jouer_ici.JouerIciPourEnvoi;

public class Case extends VBox {

	private Button bouton;
	private int indiceColonne;
	private int indiceRangee;
	private JouerIciPourEnvoi jouerIciPourEnvoi;

	public Case(int indiceRangee, int indiceColonne) {
		J.appel(this);

		HBox.setHgrow(this, Priority.ALWAYS);
		this.getStyleClass().add("conteneurBouton");

		this.indiceColonne = indiceColonne;
		this.indiceRangee = indiceRangee;

		this.bouton = new Button();
		bouton.getStyleClass().add("boutonCoup");
		this.getChildren().add(bouton);
	}

	public void setText(String text) {
		bouton.setText(text);
	}

	public void installerCapteurJouerIci() {
		J.appel(this);

		this.bouton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				J.appel(this);

				jouerIciPourEnvoi.setIndiceColonne(indiceColonne);
				jouerIciPourEnvoi.setIndiceRangee(indiceRangee);
				jouerIciPourEnvoi.envoyerCommande();
			}
		});
	}

	public void obtenirJouerIciPourEnvoi() {
		J.appel(this);

		jouerIciPourEnvoi = FabriqueCommande.obtenirCommandePourEnvoi(JouerIci.class);
	}

	public void verifierCommandePossible() {
		J.appel(this);

		jouerIciPourEnvoi.setIndiceColonne(indiceColonne);
		jouerIciPourEnvoi.setIndiceRangee(indiceRangee);
		setActif(jouerIciPourEnvoi.siCommandePossible());
	}

	public void setActif(boolean caseActive) {
		J.appel(this);

		this.bouton.setDisable(!caseActive);
	}
}