package tic_tac_toe.pages.partierecente;

import static tic_tac_toe.Constantes.CHEMIN_PARTIERECENTE_FXML;
import static tic_tac_toe.Constantes.HAUTEUR_PIXELS;
import static tic_tac_toe.Constantes.LARGEUR_PIXELS;
import java.util.Random;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.javafx.ChargeurDeVue;
import ntro.javafx.Initialisateur;
import ntro.mvc.controleurs.FabriqueControleur;
import ntro.mvc.modeles.EntrepotDeModeles;
import ntro.systeme.Systeme;
import tic_tac_toe.Constantes;

public class PagePartieRecente extends Application {

	static {

		Initialisateur.initialiser();

		J.appel(PagePartieRecente.class);
	}
	
	private Random alea = new Random();

	public static void main(String[] args) {
		J.appel(PagePartieRecente.class);
		launch(args);
	}
	
	@Override
	public void start(Stage fenetrePrincipale) throws Exception {
		J.appel(this);

		ChargeurDeVue<VuePartieRecente> chargeur;
		chargeur = new ChargeurDeVue<VuePartieRecente>(CHEMIN_PARTIERECENTE_FXML);

		VuePartieRecente vue = chargeur.getVue();

		String idModeleTest =
		Constantes.IDS_MODELES_TESTS[alea.nextInt(Constantes.IDS_MODELES_TESTS.length)];

		partieRecent partieRecente =
		EntrepotDeModeles.obtenirModele(partieRecent.class, idModeleTest);

		AfficheurPartieRecente afficheurPartieRecente = new AfficheurPartieRecente();

		DoitEtre.nonNul(vue);

		FabriqueControleur.creerControleur(ControleurPartieRecente.class, partieRecente, vue, afficheurPartieRecente);

		Scene scene = chargeur.nouvelleScene(LARGEUR_PIXELS, HAUTEUR_PIXELS);

		fenetrePrincipale.setScene(scene);

		fenetrePrincipale.setMinWidth(LARGEUR_PIXELS);
		fenetrePrincipale.setMinHeight(HAUTEUR_PIXELS);

		capterEvenementFermeture(fenetrePrincipale);

		fenetrePrincipale.show();
	}
	
	

	private void capterEvenementFermeture(Stage fenetrePrincipale) {
		J.appel(this);

		fenetrePrincipale.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				J.appel(this);

				Systeme.quitter();
			}
		});
	}
}
