package tic_tac_toe.pages.partierecente;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.controleurs.ControleurModeleVue;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import tic_tac_toe.commandes.definir_qui_gagne.DefinirQuiGagne;
import tic_tac_toe.commandes.definir_qui_gagne.DefinirQuiGagneRecue;
import tic_tac_toe.commandes.numero_partie.NumeroPartie;
import tic_tac_toe.commandes.numero_partie.NumeroPartieRecue;


public class ControleurPartieRecente
		extends ControleurModeleVue<PartieRecenteLectureSeule, partieRecent, VuePartieRecente, AfficheurPartieRecente> {

	@Override
	protected void demarrer() {
		J.appel(this);

	}

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);

		installerRecepteurCommande(DefinirQuiGagne.class, new RecepteurCommandeMVC<DefinirQuiGagneRecue>() {
			@Override
			public void executerCommandeMVC(DefinirQuiGagneRecue commande) {
				J.appel(this);

				String quiGagne = commande.getWinner();

				DoitEtre.nonNul(quiGagne);

				getModele().DefinirQuiGagne(quiGagne);
			}
		});
		
		installerRecepteurCommande(NumeroPartie.class, new RecepteurCommandeMVC<NumeroPartieRecue>() {
			@Override
			public void executerCommandeMVC(NumeroPartieRecue commande) {
				J.appel(this);
				
				String numeroPartie = commande.getNumeroPartie();

				DoitEtre.nonNul(numeroPartie);

				getModele().DefinirNumeroPartie(numeroPartie);
			}
		});

	}

	@Override
	protected void installerReceptionMessages() {
		J.appel(this);
	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);

	}

}
