package tic_tac_toe.pages.partierecente;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.messages.FabriqueMessage;
import ntro.mvc.controleurs.ControleurModeleVue;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import ntro.mvc.controleurs.RecepteurMessageMVC;
import tic_tac_toe.commandes.definir_qui_gagne.DefinirQuiGagne;
import tic_tac_toe.commandes.definir_qui_gagne.DefinirQuiGagneRecue;
import tic_tac_toe.commandes.numero_partie.NumeroPartie;
import tic_tac_toe.commandes.numero_partie.NumeroPartieRecue;
import tic_tac_toe.messages.transmettre_numeropartie.MsgTransmettreNumeroPartie;
import tic_tac_toe.messages.transmettre_numeropartie.MsgTransmettreNumeroPartiePourEnvoi;
import tic_tac_toe.messages.transmettre_numeropartie.MsgTransmettreNumeroPartieRecu;
import tic_tac_toe.messages.transmettre_qui_gagne.MsgTransmettreQuiGagne;
import tic_tac_toe.messages.transmettre_qui_gagne.MsgTransmettreQuiGagnePourEnvoi;
import tic_tac_toe.messages.transmettre_qui_gagne.MsgTransmettreQuiGagneRecu;

public class ControleurPartieRecente
		extends ControleurModeleVue<PartieRecenteLectureSeule, partieRecent, VuePartieRecente, AfficheurPartieRecente> {

	private MsgTransmettreQuiGagnePourEnvoi msgTransmettreQuiGagne;
	private MsgTransmettreNumeroPartiePourEnvoi msgTransmettreNumeroPartie;

	@Override
	protected void demarrer() {
		J.appel(this);

	}

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);

		installerRecepteurCommande(DefinirQuiGagne.class, new RecepteurCommandeMVC<DefinirQuiGagneRecue>() {
			@Override
			public void executerCommandeMVC(DefinirQuiGagneRecue commande) {
				J.appel(this);

				String quiGagne = commande.getWinner();

				DoitEtre.nonNul(quiGagne);

				getModele().DefinirQuiGagne(quiGagne);

				msgTransmettreQuiGagne.setQuiGagne(quiGagne);
				msgTransmettreNumeroPartie.envoyerMessage();
			}
		});

		installerRecepteurCommande(NumeroPartie.class, new RecepteurCommandeMVC<NumeroPartieRecue>() {
			@Override
			public void executerCommandeMVC(NumeroPartieRecue commande) {
				J.appel(this);

				String numeroPartie = commande.getNumeroPartie();

				DoitEtre.nonNul(numeroPartie);

				getModele().DefinirNumeroPartie(numeroPartie);
			}
		});

	}

	@Override
	protected void installerReceptionMessages() {
		J.appel(this);

		installerRecepteurMessage(MsgTransmettreQuiGagne.class, new RecepteurMessageMVC<MsgTransmettreQuiGagneRecu>() {

			@Override
			public void recevoirMessageMVC(MsgTransmettreQuiGagneRecu messageRecu) {
				J.appel(this);

				String quiGagne = messageRecu.getQuiGagne();

				DoitEtre.nonNul(quiGagne);

				getModele().DefinirQuiGagne(quiGagne);
			}
		});

		installerRecepteurMessage(MsgTransmettreNumeroPartie.class,
				new RecepteurMessageMVC<MsgTransmettreNumeroPartieRecu>() {

					@Override
					public void recevoirMessageMVC(MsgTransmettreNumeroPartieRecu messageRecu) {
						J.appel(this);

						String numPartie = messageRecu.getNumPartie();

						DoitEtre.nonNul(numPartie);

						getModele().DefinirNumeroPartie(numPartie);
					}
				});
	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);

		msgTransmettreQuiGagne = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreQuiGagne.class);
		msgTransmettreNumeroPartie = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreNumeroPartie.class);

	}

}
