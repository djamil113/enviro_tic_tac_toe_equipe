package tic_tac_toe.pages.parametresBack;
import tic_tac_toe.enumerations.*;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.modeles.Modele;



public class ParametresBack extends Modele<ParametresLectureSeule> implements ParametresLectureSeule {
	
	private Couleurs colorBackground;
	private Couleurs colorForm;
	private Couleurs colorBorder;
	

	@Override
	public void apresCreation() {
		J.appel(this);
		colorBackground = Couleurs.JAUNE;
		colorForm = Couleurs.VERT;
		colorBorder = Couleurs.BLACK;
	
	}

	@Override
	public void apresChargementJson() {
		J.appel(this);
		DoitEtre.nonNul(colorBackground);
		DoitEtre.nonNul(colorForm);
		DoitEtre.nonNul(colorBorder);
	
	}
	
	
	
	public void choisirColorBack(Couleurs choixColorBackground) {
		J.appel(this);
		
		this.colorBackground = choixColorBackground;
	}
	public void choisirColorForm(Couleurs formeColor) {
		J.appel(this);
		
		this.colorForm = formeColor;
	}
	public void choisirColorBorder(Couleurs choixColorBorder) {
		J.appel(this);
		
		this.colorBorder = choixColorBorder;
	}
	
	
	

	@Override
	public Couleurs getColorBackground() {
		J.appel(this);
		
		return colorBackground;
	}
	
	@Override
	public Couleurs getColorForm() {
		J.appel(this);
		
		return colorForm;
	}

	@Override
	public Couleurs getColorBorder() {
		J.appel(this);
		
		return colorBorder;
	}

}