package tic_tac_toe.pages.partie.modeles;

public class      PartieReseau 
       extends    Partie<PartieReseauLectureSeule> 
       implements PartieReseauLectureSeule {

}
