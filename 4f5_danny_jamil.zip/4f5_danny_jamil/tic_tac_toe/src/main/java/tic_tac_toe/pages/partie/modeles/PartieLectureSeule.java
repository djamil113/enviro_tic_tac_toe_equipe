package tic_tac_toe.pages.partie.modeles;

import ntro.mvc.modeles.ModeleLectureSeule;

public interface PartieLectureSeule extends ModeleLectureSeule {

	GrilleLectureSeule getGrille();
	int getLargeur();
	int getHauteur();
}
