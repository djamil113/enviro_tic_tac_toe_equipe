package tic_tac_toe.pages.partie.modeles;

import java.util.List;

public interface ColonneLectureSeule {

	List<CaseLectureSeule> getCases();

	int getIdColonne();

}
