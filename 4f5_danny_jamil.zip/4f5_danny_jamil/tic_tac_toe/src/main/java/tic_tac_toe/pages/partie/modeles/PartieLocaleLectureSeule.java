package tic_tac_toe.pages.partie.modeles;

public interface PartieLocaleLectureSeule extends PartieLectureSeule {

}
