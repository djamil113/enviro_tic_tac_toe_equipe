package tic_tac_toe.pages.parametresBack;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.messages.FabriqueMessage;
import ntro.mvc.controleurs.ControleurModeleVue;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import ntro.mvc.controleurs.RecepteurMessageMVC;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBackground;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBackgroundRecue;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBordure;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBordureRecue;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurForme;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurFormeRecue;
import tic_tac_toe.enumerations.Couleurs;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurBack;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurBackPourEnvoie;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurBackRecue;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurBordure;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurBordurePourEnvoie;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurBordureRecue;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurForme;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurFormePourEnvoie;
import tic_tac_toe.messages.transmettre_Couleurs.MsgTransmettreCouleurFormeRecue;




public class ControleurParametresBack
		extends ControleurModeleVue<ParametresLectureSeule, ParametresBack, VueParametresBack, AfficheurParametresBack> {


	@Override
	protected void demarrer() {
		J.appel(this);

	}
	private MsgTransmettreCouleurBackPourEnvoie msgTransmettreCouleurBack;
	private MsgTransmettreCouleurBordurePourEnvoie msgTransmettreCouleurBordure;
	private MsgTransmettreCouleurFormePourEnvoie msgTransmettreCouleurForme;

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);
		
		installerRecepteurCommande(ChoisirCouleurForme.class, new RecepteurCommandeMVC<ChoisirCouleurFormeRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirCouleurFormeRecue commande) {
				J.appel(this);
				
				Couleurs FormeColor = commande.getCouleur();

				DoitEtre.nonNul(FormeColor);

				getModele().choisirColorForm(FormeColor);
				
				msgTransmettreCouleurForme.setCouleurForme(FormeColor);
				msgTransmettreCouleurForme.envoyerMessage();
			}
			
		});
		installerRecepteurCommande(ChoisirCouleurBackground.class, new RecepteurCommandeMVC<ChoisirCouleurBackgroundRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirCouleurBackgroundRecue commande) {
				J.appel(this);
				
				Couleurs FondColor = commande.getCouleur();

				DoitEtre.nonNul(FondColor);

				getModele().choisirColorBack(FondColor);
				
				msgTransmettreCouleurBack.setCouleurBack(FondColor);
				msgTransmettreCouleurBack.envoyerMessage();
			}
			
		});
		installerRecepteurCommande(ChoisirCouleurBordure.class, new RecepteurCommandeMVC<ChoisirCouleurBordureRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirCouleurBordureRecue commande) {
				J.appel(this);
				
				Couleurs BordureColor = commande.getCouleur();

				DoitEtre.nonNul(BordureColor);

				getModele().choisirColorBorder(BordureColor);
				
				msgTransmettreCouleurBordure.setCouleurBordure(BordureColor);
				msgTransmettreCouleurBordure.envoyerMessage();
			}
			
		});
		
	}

	@Override
	protected void installerReceptionMessages() {
		J.appel(this);
		
		installerRecepteurMessage(MsgTransmettreCouleurBack.class, new RecepteurMessageMVC<MsgTransmettreCouleurBackRecue>() {

			@Override
			public void recevoirMessageMVC(MsgTransmettreCouleurBackRecue messageRecu) {
				J.appel(this);
				
				Couleurs FondColor = messageRecu.getCouleurBack();
				
				DoitEtre.nonNul(FondColor);
				
				getModele().choisirColorBack(FondColor);
			}
		});
		
		installerRecepteurMessage(MsgTransmettreCouleurBordure.class, new RecepteurMessageMVC<MsgTransmettreCouleurBordureRecue>() {

			@Override
			public void recevoirMessageMVC(MsgTransmettreCouleurBordureRecue messageRecu) {
				J.appel(this);
				
				Couleurs BordureColor = messageRecu.getCouleurBordure();
				
				DoitEtre.nonNul(BordureColor);
				
				getModele().choisirColorBorder(BordureColor);
			}
		});
		installerRecepteurMessage(MsgTransmettreCouleurForme.class, new RecepteurMessageMVC<MsgTransmettreCouleurFormeRecue>() {

			@Override
			public void recevoirMessageMVC(MsgTransmettreCouleurFormeRecue messageRecu) {
				J.appel(this);
				
				Couleurs FormeColor = messageRecu.getCouleurForme();
				
				DoitEtre.nonNul(FormeColor);
				
				getModele().choisirColorForm(FormeColor);
			}
		});

	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);
		
		msgTransmettreCouleurBack = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreCouleurBack.class);
		msgTransmettreCouleurBordure = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreCouleurBordure.class);
		msgTransmettreCouleurForme = FabriqueMessage.obtenirMessagePourEnvoi(MsgTransmettreCouleurForme.class);

	}

}
