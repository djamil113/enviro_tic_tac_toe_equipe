package tic_tac_toe.pages.parametresBack;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.controleurs.ControleurModeleVue;
import ntro.mvc.controleurs.RecepteurCommandeMVC;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBackground;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBackgroundRecue;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBordure;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurBordureRecue;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurForme;
import tic_tac_toe.commandes.choisir_couleurs.ChoisirCouleurFormeRecue;
import tic_tac_toe.enumerations.Couleurs;


public class ControleurParametresBack
		extends ControleurModeleVue<ParametresBackLectureSeule, ParametresBack, VueParametresBack, AfficheurParametresBack> {

	@Override
	protected void demarrer() {
		J.appel(this);

	}

	@Override
	protected void installerReceptionCommandes() {
		J.appel(this);
		
		installerRecepteurCommande(ChoisirCouleurForme.class, new RecepteurCommandeMVC<ChoisirCouleurFormeRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirCouleurFormeRecue commande) {
				J.appel(this);
				
				Couleurs FormeColor = commande.getCouleur();

				DoitEtre.nonNul(FormeColor);

				getModele().choisirColorForm(FormeColor);
			}
			
		});
		installerRecepteurCommande(ChoisirCouleurBackground.class, new RecepteurCommandeMVC<ChoisirCouleurBackgroundRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirCouleurBackgroundRecue commande) {
				J.appel(this);
				
				Couleurs FondColor = commande.getCouleur();

				DoitEtre.nonNul(FondColor);

				getModele().choisirColorBack(FondColor);
			}
			
		});
		installerRecepteurCommande(ChoisirCouleurBordure.class, new RecepteurCommandeMVC<ChoisirCouleurBordureRecue>() {
			@Override
			public void executerCommandeMVC(ChoisirCouleurBordureRecue commande) {
				J.appel(this);
				
				Couleurs BordureColor = commande.getCouleur();

				DoitEtre.nonNul(BordureColor);

				getModele().choisirColorBorder(BordureColor);
			}
			
		});
		
	}

	@Override
	protected void installerReceptionMessages() {
		J.appel(this);

	}

	@Override
	protected void obtenirMessagesPourEnvoi() {
		J.appel(this);

	}

}
