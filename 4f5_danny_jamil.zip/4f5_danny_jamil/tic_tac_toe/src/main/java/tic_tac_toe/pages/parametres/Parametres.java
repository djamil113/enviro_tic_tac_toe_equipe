package tic_tac_toe.pages.parametres;

import ntro.debogage.DoitEtre;
import ntro.debogage.J;
import ntro.mvc.modeles.Modele;
import tic_tac_toe.enumerations.Forme;
import tic_tac_toe.enumerations.TailleGrille;

public class Parametres extends Modele<ParametresLectureSeule> implements ParametresLectureSeule{

	private Forme quiCommence;
	private TailleGrille tailleGrille;

	@Override
	public void apresCreation() {
		J.appel(this);

		quiCommence = Forme.X;
		tailleGrille = TailleGrille.PETITE;
	}

	@Override
	public void apresChargementJson() {
		J.appel(this);
		
		DoitEtre.nonNul(quiCommence);
		DoitEtre.nonNul(tailleGrille);
	}

	@Override
	public Forme getQuiCommence() {
		J.appel(this);

		return quiCommence;
	}

	public void choisirQuiCommence(Forme joueurQuiCommence) {
		J.appel(this);
		
		this.quiCommence = joueurQuiCommence;
	}

	public void choisirTailleGrille(TailleGrille tailleGrille) {
		J.appel(this);
		
		this.tailleGrille = tailleGrille;
	}

	@Override
	public TailleGrille getTailleGrille() {
		return tailleGrille;
	}
}
