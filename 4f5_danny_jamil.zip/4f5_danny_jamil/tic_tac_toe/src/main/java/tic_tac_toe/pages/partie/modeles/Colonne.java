package tic_tac_toe.pages.partie.modeles;

import java.util.ArrayList;

import java.util.List;

import tic_tac_toe.enumerations.Forme;
import ntro.debogage.J;

public class Colonne implements ColonneLectureSeule {

	// private List<Case> cases = new ArrayList<>();
	private List<Case> cases = new ArrayList<>();
	private transient int idColonne;

	public void ajouterCase(Forme forme, int indiceRangee) {
		J.appel(this);

		Case _case = new Case();

		_case.setForme(forme);
		_case.setIndiceColonne(idColonne);
		_case.setIndiceRangee(indiceRangee);

		this.cases.add(_case);
	}

	@Override
	public List<CaseLectureSeule> getCases() {
		J.appel(this);

		List<CaseLectureSeule> casesLectureSeule = new ArrayList<>();

		for (Case Case : cases) {

			casesLectureSeule.add((CaseLectureSeule) Case);
		}

		return casesLectureSeule;
	}

	public int getIdColonne() {
		return idColonne;
	}

	public void setIdColonne(int idColonne) {
		this.idColonne = idColonne;
	}

	public boolean siPossibleJouerIci(int hauteur) {
		J.appel(this);

		return cases.size() < hauteur;
	}

	public void apresChargementJson(int indiceCol) {
		J.appel(this);

		this.idColonne = indiceCol;

		for (int indiceRangee = 0; indiceRangee < cases.size(); indiceRangee++) {
			Case Case = this.cases.get(indiceRangee);
			Case.setIndiceColonne(this.idColonne);
			Case.setIndiceRangee(indiceRangee);
		}
	}
}
