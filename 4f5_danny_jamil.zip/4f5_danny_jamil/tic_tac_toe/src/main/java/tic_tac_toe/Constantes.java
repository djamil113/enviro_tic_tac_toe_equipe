package tic_tac_toe;

import tic_tac_toe.enumerations.TailleGrille;

public class Constantes {

	public static final String ID_MODELE_PAR_DEFAUT = "default";
	
	public static final String CHEMIN_CHAINES = "traductions.chaines";
	
	public static final String CHEMIN_PRINCIPAL_FXML = "/accueil/structure.xml";
	public static final String CHEMIN_PRINCIPAL_CSS = "/accueil/style.css";
	
	public static final String CHEMIN_PARTIE_LOCALE_FXML = "/partie/locale/structure.xml";
	public static final String CHEMIN_PARTIE_LOCALE_CSS = "/partie/locale/style.css";
	
    public static final String CHEMIN_PARAMETRES_FXML = "/parametres/structure.xml";
    public static final String CHEMIN_PARAMETRES_CSS = "/parametres/style.css";
    
    public static final String CHEMIN_PARTIERECENTE_FXML = "/partieRecente/structure.xml";
    public static final String CHEMIN_PARTIERECENTE_CSS = "/partieRecente/style.css";
    
    public static final String CHEMIN_PARAMETRES_BACK_FXML = "/parametreBackground/structure.xml";
    public static final String CHEMIN_PRINCIPAL_BACK_CSS = "/parametreBackground/style.css";
    
    public static final String CHEMIN_PARTIE_RESEAU_FXML = "/partie/reseau/structure.xml";
    public static final String CHEMIN_PARTIE_RESEAU_CSS = "/partie/reseau/style.css";
    
	public static final int HAUTEUR_GRILLE_PETITE = 3;
	public static final int HAUTEUR_GRILLE_MOYENNE = 4;
	public static final int HAUTEUR_GRILLE_GRANDE = 5;

	public static final int LARGEUR_GRILLE_PETITE = 3;
	public static final int LARGEUR_GRILLE_MOYENNE = 4;
	public static final int LARGEUR_GRILLE_GRANDE = 5;

	public static final TailleGrille TAILLE_GRILLE_PAR_DEFAUT = TailleGrille.PETITE;
	
	public static final int PORT = 8765;
	public static final String ADRESSE_SERVEUR = String.format("ws://localhost:%s", PORT);

	public static final int TAILLE_CASE = 40;

	public static final int LARGEUR_PIXELS_MIN = 400;
	public static final int HAUTEUR_PIXELS_MIN = 600;

	public static final int LARGEUR_PIXELS = 600;
	public static final int HAUTEUR_PIXELS = 800;

	public static final int LARGEUR_PARAMETRES_PIXELS_MIN = 250;
	public static final int HAUTEUR_PARAMETRES_PIXELS_MIN = 500;

	public static final int LARGEUR_PARAMETRES_PIXELS = 300;
	public static final int HAUTEUR_PARAMETRES_PIXELS = 520;

	public static final int LARGEUR_PARAMETRES_PIXELS_MAX = 350;
	public static final int HAUTEUR_PARAMETRES_PIXELS_MAX = 540;
	
	public static final int TAILLE_POLICE = 15;
	public static final int TAILLE_POLICE_MIN = 11;
	public static final int TAILLE_POLICE_MAX = 18;

	public static double AJUSTEMENT_TAILLE_PIXELS = 1.0;
}
