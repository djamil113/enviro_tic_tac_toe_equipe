
package tic_tac_toe.commandes.fermer_parametresBack;

import ntro.commandes.CommandePourEnvoi;

public interface FermerParametresBackPourEnvoi extends CommandePourEnvoi {

}
