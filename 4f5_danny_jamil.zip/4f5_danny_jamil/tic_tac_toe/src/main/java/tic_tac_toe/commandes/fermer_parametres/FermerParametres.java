
package tic_tac_toe.commandes.fermer_parametres;

import ntro.commandes.Commande;

public class FermerParametres extends Commande<FermerParametresPourEnvoi, 
                                               FermerParametresRecue>

							  implements FermerParametresPourEnvoi,
							             FermerParametresRecue {
}
