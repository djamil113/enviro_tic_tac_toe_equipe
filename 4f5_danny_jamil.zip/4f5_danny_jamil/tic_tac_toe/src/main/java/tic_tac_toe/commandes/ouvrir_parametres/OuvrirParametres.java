package tic_tac_toe.commandes.ouvrir_parametres;

import ntro.commandes.Commande;

public class OuvrirParametres extends Commande<OuvrirParametresPourEnvoi, 
                                               OuvrirParametresRecue>

							  implements OuvrirParametresPourEnvoi,
							             OuvrirParametresRecue {
}
