package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.CommandePourEnvoi;
import tic_tac_toe.enumerations.*;

public interface ChoisirCouleurFormePourEnvoie extends CommandePourEnvoi{

	void setCouleur(Couleurs marque);
}
