package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.CommandeRecue;
import tic_tac_toe.enumerations.*;

public interface ChoisirCouleurFormeRecue extends CommandeRecue {

	Couleurs getCouleur();
}
