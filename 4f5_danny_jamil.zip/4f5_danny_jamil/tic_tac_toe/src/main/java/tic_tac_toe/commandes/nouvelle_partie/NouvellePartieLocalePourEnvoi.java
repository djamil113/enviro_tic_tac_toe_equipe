package tic_tac_toe.commandes.nouvelle_partie;

import ntro.commandes.CommandePourEnvoi;

public interface NouvellePartieLocalePourEnvoi extends CommandePourEnvoi {

}
