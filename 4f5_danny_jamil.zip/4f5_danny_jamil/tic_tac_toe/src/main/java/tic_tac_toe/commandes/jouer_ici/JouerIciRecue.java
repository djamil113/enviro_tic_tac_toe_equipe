package tic_tac_toe.commandes.jouer_ici;

import ntro.commandes.CommandeRecue;

public interface JouerIciRecue extends CommandeRecue {
	
	int getIndiceColonne();
	int getIndiceRangee();
}
