package tic_tac_toe.commandes.ouvrir_partieRecente;

import ntro.commandes.CommandeRecue;

public interface OuvrirPartieRecenteRecue extends CommandeRecue {

}
