package tic_tac_toe.commandes.ouvrir_parametresBack;

import ntro.commandes.Commande;

public class OuvrirParametresBack extends Commande<OuvrirParametresBackPourEnvoi, 
                                               OuvrirParametresBackRecue>

							  implements OuvrirParametresBackPourEnvoi,
							             OuvrirParametresBackRecue {
}
