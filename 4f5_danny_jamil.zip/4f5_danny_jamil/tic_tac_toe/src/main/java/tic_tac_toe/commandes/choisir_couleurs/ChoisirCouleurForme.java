package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.Commande;
import ntro.debogage.J;
import tic_tac_toe.enumerations.*;

public class ChoisirCouleurForme extends Commande<ChoisirCouleurFormePourEnvoie, ChoisirCouleurFormeRecue>
implements ChoisirCouleurFormePourEnvoie, ChoisirCouleurFormeRecue { 
	
	private Couleurs couleurForme;

	@Override
	public Couleurs getCouleur() {
		J.appel(this);

		return couleurForme;
	}

	@Override
	public void setCouleur(Couleurs marque) {
		J.appel(this);

		this.couleurForme = marque;

	}

}
