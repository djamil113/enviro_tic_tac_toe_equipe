package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.CommandeRecue;
import tic_tac_toe.enumerations.Couleurs;

public interface ChoisirCouleurBackgroundRecue extends CommandeRecue {

	Couleurs getCouleur();
}
