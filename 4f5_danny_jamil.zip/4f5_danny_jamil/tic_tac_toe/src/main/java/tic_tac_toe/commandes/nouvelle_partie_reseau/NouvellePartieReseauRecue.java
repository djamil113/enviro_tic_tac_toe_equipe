package tic_tac_toe.commandes.nouvelle_partie_reseau;

import ntro.commandes.CommandeRecue;

public interface NouvellePartieReseauRecue extends CommandeRecue {

}
