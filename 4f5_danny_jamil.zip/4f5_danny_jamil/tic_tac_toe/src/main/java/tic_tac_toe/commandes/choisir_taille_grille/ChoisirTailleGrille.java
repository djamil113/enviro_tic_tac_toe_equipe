package tic_tac_toe.commandes.choisir_taille_grille;

import ntro.commandes.Commande;
import ntro.debogage.J;
import tic_tac_toe.enumerations.TailleGrille;

public class ChoisirTailleGrille extends Commande<ChoisirTailleGrillePourEnvoi, ChoisirTailleGrilleRecue> 
implements ChoisirTailleGrillePourEnvoi, ChoisirTailleGrilleRecue {

	private TailleGrille tailleGrille;
	
	@Override
	public TailleGrille getTailleGrille() {
		J.appel( this );
		return tailleGrille;
	}

	@Override
	public void setTailleGrille( TailleGrille taille ) {
		J.appel( this );
		
		this.tailleGrille = taille;
	}

}
