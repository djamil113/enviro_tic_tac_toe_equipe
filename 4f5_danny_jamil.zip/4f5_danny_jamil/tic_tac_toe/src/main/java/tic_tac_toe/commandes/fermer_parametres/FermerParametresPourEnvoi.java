
package tic_tac_toe.commandes.fermer_parametres;

import ntro.commandes.CommandePourEnvoi;

public interface FermerParametresPourEnvoi extends CommandePourEnvoi {

}
