
package tic_tac_toe.commandes.quitter;

import ntro.commandes.CommandePourEnvoi;

public interface QuitterPourEnvoi extends CommandePourEnvoi {

}
