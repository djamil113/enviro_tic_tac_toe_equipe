package tic_tac_toe.commandes.numero_partie;

import ntro.commandes.CommandePourEnvoi;
import tic_tac_toe.enumerations.numPartie;

public interface NumeroPartiePourEnvoi extends CommandePourEnvoi {
	
	void setNumeroPartie(String numeroPartie);

}
