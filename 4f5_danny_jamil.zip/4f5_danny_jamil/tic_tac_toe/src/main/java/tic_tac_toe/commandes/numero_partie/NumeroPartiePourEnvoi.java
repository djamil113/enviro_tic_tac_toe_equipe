package tic_tac_toe.commandes.numero_partie;

import ntro.commandes.CommandePourEnvoi;

public interface NumeroPartiePourEnvoi extends CommandePourEnvoi {
	
	void setNumeroPartie(String numeroPartie);

}
