
package tic_tac_toe.commandes.quitter;

import ntro.commandes.CommandeRecue;

public interface QuitterRecue extends CommandeRecue {

}
