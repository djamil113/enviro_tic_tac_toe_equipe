package tic_tac_toe.commandes.definir_qui_gagne;

import ntro.commandes.Commande;
import tic_tac_toe.enumerations.Winner;
import ntro.debogage.J;

public class DefinirQuiGagne extends Commande<DefinirQuiGagnePourEnvoi, DefinirQuiGagneRecue>
		implements DefinirQuiGagnePourEnvoi, DefinirQuiGagneRecue {

	private String winner;

	@Override
	public String getWinner() {
		J.appel(this);
		return winner;
	}

	@Override
	public void setWinner(String winner) {
		J.appel(this);

		this.winner = winner;

	}

}
