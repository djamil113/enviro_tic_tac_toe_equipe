
package tic_tac_toe.commandes.fermer_parametresBack;

import ntro.commandes.Commande;

public class FermerParametresBack extends Commande<FermerParametresBackPourEnvoi, 
                                               FermerParametresBackRecue>

							  implements FermerParametresBackPourEnvoi,
							             FermerParametresBackRecue {
}
