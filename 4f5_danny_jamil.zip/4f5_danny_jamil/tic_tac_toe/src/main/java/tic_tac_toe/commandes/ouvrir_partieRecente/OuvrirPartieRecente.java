package tic_tac_toe.commandes.ouvrir_partieRecente;

import ntro.commandes.Commande;

public class OuvrirPartieRecente extends Commande<OuvrirPartieRecentePourEnvoi, 
                                               OuvrirPartieRecenteRecue>

							  implements OuvrirPartieRecentePourEnvoi,
							  			 OuvrirPartieRecenteRecue {
}
