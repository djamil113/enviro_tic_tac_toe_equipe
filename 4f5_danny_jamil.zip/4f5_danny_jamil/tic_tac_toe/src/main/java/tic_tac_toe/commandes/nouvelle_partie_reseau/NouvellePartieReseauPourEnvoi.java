package tic_tac_toe.commandes.nouvelle_partie_reseau;

import ntro.commandes.CommandePourEnvoi;

public interface NouvellePartieReseauPourEnvoi extends CommandePourEnvoi {

}
