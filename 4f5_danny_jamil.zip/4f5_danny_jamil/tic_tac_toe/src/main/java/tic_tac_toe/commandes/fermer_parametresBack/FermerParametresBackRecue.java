
package tic_tac_toe.commandes.fermer_parametresBack;

import ntro.commandes.CommandeRecue;

public interface FermerParametresBackRecue extends CommandeRecue {

}
