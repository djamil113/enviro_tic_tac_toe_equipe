package tic_tac_toe.commandes.ouvrir_parametres;

import ntro.commandes.CommandeRecue;

public interface OuvrirParametresRecue extends CommandeRecue {

}
