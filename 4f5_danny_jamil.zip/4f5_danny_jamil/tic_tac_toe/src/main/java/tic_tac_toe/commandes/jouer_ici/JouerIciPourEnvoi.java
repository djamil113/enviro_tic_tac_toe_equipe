package tic_tac_toe.commandes.jouer_ici;

import ntro.commandes.CommandePourEnvoi;

public interface JouerIciPourEnvoi extends CommandePourEnvoi {

	void setIndiceColonne(int indiceColonne);
	void setIndiceRangee(int indiceRangee);
}
