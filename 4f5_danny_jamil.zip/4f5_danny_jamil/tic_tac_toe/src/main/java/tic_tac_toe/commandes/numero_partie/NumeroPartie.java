package tic_tac_toe.commandes.numero_partie;

import ntro.commandes.Commande;
import ntro.debogage.J;
import tic_tac_toe.enumerations.numPartie;

public class NumeroPartie extends Commande<NumeroPartiePourEnvoi, NumeroPartieRecue>
		implements NumeroPartiePourEnvoi, NumeroPartieRecue {

	private String numeroPartie;

	@Override
	public String getNumeroPartie() {
		J.appel(this);
		return numeroPartie;
	}

	@Override
	public void setNumeroPartie(String numeroPartie) {
		J.appel(this);

		this.numeroPartie = numeroPartie;

	}

}
