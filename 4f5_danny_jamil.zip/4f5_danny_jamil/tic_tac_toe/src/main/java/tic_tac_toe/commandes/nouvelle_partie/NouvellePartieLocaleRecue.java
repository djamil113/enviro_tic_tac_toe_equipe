package tic_tac_toe.commandes.nouvelle_partie;

import ntro.commandes.CommandeRecue;

public interface NouvellePartieLocaleRecue extends CommandeRecue {

}
