package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.CommandePourEnvoi;
import tic_tac_toe.enumerations.Couleurs;


public interface ChoisirCouleurBordurePourEnvoie extends CommandePourEnvoi {
	
	void setCouleur(Couleurs marque);
}
