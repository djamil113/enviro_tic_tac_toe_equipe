package tic_tac_toe.commandes.choisir_taille_grille;

import ntro.commandes.CommandePourEnvoi;
import tic_tac_toe.enumerations.TailleGrille;

public interface ChoisirTailleGrillePourEnvoi extends CommandePourEnvoi {
	
	void setTailleGrille(TailleGrille taille);

}
