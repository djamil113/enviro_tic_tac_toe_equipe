package tic_tac_toe.commandes.choisir_qui_commence;

import tic_tac_toe.enumerations.Forme;
import ntro.commandes.CommandePourEnvoi;

public interface ChoisirQuiCommencePourEnvoi extends CommandePourEnvoi {
	
	void setForme(Forme forme);

}
