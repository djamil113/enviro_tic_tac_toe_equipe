package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.Commande;
import ntro.debogage.J;
import tic_tac_toe.enumerations.Couleurs;

public class ChoisirCouleurBackground extends Commande<ChoisirCouleurBackgroundPourEnvoie, ChoisirCouleurBackgroundRecue>
implements ChoisirCouleurBackgroundPourEnvoie, ChoisirCouleurBackgroundRecue {

	private Couleurs couleurFond;

	@Override
	public Couleurs getCouleur() {
		J.appel(this);

		return couleurFond;
	}

	@Override
	public void setCouleur(Couleurs marque) {
		J.appel(this);

		this.couleurFond = marque;

	}
}
