package tic_tac_toe.commandes.choisir_qui_commence;

import tic_tac_toe.enumerations.Forme;
import ntro.commandes.CommandeRecue;

public interface ChoisirQuiCommenceRecue extends CommandeRecue {
	
	Forme getForme();

}
