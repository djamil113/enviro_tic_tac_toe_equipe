package tic_tac_toe.commandes.nouvelle_partie;

import ntro.commandes.Commande;

public class NouvellePartieLocale extends Commande<NouvellePartieLocalePourEnvoi, 
                                             	   NouvellePartieLocaleRecue>

								  implements NouvellePartieLocalePourEnvoi, 
							           		 NouvellePartieLocaleRecue {
}
