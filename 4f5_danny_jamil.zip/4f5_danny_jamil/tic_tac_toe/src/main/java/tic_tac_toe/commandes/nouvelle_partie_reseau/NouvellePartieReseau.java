package tic_tac_toe.commandes.nouvelle_partie_reseau;

import ntro.commandes.Commande;

public class NouvellePartieReseau extends Commande<NouvellePartieReseauPourEnvoi, 
                                             NouvellePartieReseauRecue>

							implements NouvellePartieReseauPourEnvoi, 
							           NouvellePartieReseauRecue {
}
