package tic_tac_toe.commandes.choisir_couleurs;

import ntro.commandes.Commande;
import ntro.debogage.J;
import tic_tac_toe.enumerations.*;

public class ChoisirCouleurBordure extends Commande<ChoisirCouleurBordurePourEnvoie, ChoisirCouleurBordureRecue>
		implements ChoisirCouleurBordurePourEnvoie, ChoisirCouleurBordureRecue {

	private Couleurs couleurBordure;

	@Override
	public Couleurs getCouleur() {
		J.appel(this);

		return couleurBordure;
	}

	@Override
	public void setCouleur(Couleurs marque) {
		J.appel(this);

		this.couleurBordure = marque;

	}

}
