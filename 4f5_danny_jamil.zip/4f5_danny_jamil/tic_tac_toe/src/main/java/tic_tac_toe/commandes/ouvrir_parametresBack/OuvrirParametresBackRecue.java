package tic_tac_toe.commandes.ouvrir_parametresBack;

import ntro.commandes.CommandeRecue;

public interface OuvrirParametresBackRecue extends CommandeRecue {

}
