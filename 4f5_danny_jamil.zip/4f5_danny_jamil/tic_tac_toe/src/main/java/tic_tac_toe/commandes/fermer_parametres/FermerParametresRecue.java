
package tic_tac_toe.commandes.fermer_parametres;

import ntro.commandes.CommandeRecue;

public interface FermerParametresRecue extends CommandeRecue {

}
