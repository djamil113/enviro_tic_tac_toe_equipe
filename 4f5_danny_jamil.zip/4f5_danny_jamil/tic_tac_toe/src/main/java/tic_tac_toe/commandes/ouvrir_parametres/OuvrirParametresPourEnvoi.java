package tic_tac_toe.commandes.ouvrir_parametres;

import ntro.commandes.CommandePourEnvoi;

public interface OuvrirParametresPourEnvoi extends CommandePourEnvoi {

}
