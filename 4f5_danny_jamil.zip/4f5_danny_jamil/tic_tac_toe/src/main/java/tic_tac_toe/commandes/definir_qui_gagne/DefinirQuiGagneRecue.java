package tic_tac_toe.commandes.definir_qui_gagne;

import ntro.commandes.CommandeRecue;
import tic_tac_toe.enumerations.Winner;


public interface DefinirQuiGagneRecue extends CommandeRecue {
	
	String getWinner();
	

}
