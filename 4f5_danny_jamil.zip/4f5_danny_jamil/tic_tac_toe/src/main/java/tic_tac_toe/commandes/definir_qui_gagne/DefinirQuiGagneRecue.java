package tic_tac_toe.commandes.definir_qui_gagne;

import ntro.commandes.CommandeRecue;


public interface DefinirQuiGagneRecue extends CommandeRecue {
	
	String getWinner();
	

}
