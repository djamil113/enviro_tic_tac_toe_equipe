package tic_tac_toe.commandes.choisir_taille_grille;

import tic_tac_toe.enumerations.TailleGrille;
import ntro.commandes.CommandeRecue;

public interface ChoisirTailleGrilleRecue extends CommandeRecue {
	
	TailleGrille getTailleGrille();

}
