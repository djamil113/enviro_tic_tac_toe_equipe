package tic_tac_toe.commandes.numero_partie;

import ntro.commandes.CommandeRecue;
import tic_tac_toe.enumerations.numPartie;

public interface NumeroPartieRecue extends CommandeRecue {

	String getNumeroPartie();

}