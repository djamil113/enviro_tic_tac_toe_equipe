package tic_tac_toe.commandes.choisir_qui_commence;

import ntro.commandes.Commande;
import ntro.debogage.J;
import tic_tac_toe.enumerations.Forme;

public class ChoisirQuiCommence extends Commande <ChoisirQuiCommencePourEnvoi, ChoisirQuiCommenceRecue> 
					implements ChoisirQuiCommencePourEnvoi, ChoisirQuiCommenceRecue {
		
	private Forme forme;
	
	@Override
	public Forme getForme() { 
		J.appel(this);
		
		return forme;
	}
	
	@Override
	public void setForme(Forme marque) {
		J.appel(this);
		
		this.forme = marque;
	}
	
}


