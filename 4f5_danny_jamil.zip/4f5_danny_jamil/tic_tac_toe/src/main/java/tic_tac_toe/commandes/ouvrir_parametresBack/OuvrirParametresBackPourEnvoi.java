package tic_tac_toe.commandes.ouvrir_parametresBack;

import ntro.commandes.CommandePourEnvoi;

public interface OuvrirParametresBackPourEnvoi extends CommandePourEnvoi {

}
