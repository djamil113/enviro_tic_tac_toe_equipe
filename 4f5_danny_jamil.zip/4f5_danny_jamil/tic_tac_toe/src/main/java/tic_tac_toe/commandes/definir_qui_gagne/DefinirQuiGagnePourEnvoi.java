package tic_tac_toe.commandes.definir_qui_gagne;

import ntro.commandes.CommandePourEnvoi;

public interface DefinirQuiGagnePourEnvoi extends CommandePourEnvoi {
	
	void setWinner(String winner);
	

}
