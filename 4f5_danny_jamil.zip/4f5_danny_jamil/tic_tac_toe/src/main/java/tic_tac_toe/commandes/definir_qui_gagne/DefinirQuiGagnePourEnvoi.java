package tic_tac_toe.commandes.definir_qui_gagne;

import tic_tac_toe.enumerations.Winner;
import ntro.commandes.CommandePourEnvoi;

public interface DefinirQuiGagnePourEnvoi extends CommandePourEnvoi {
	
	void setWinner(String winner);
	

}
