package tic_tac_toe.messages.transmettre_coup;

import ntro.messages.MessagePourEnvoi;

public interface MsgTransmettreCoupPourEnvoi extends MessagePourEnvoi {
	
	void setIndiceColonne(int indiceColonne);
	void setIndiceRangee(int indiceRangee);

}
