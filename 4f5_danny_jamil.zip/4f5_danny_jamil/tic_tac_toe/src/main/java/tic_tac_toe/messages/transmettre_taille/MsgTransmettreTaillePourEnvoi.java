package tic_tac_toe.messages.transmettre_taille;

import tic_tac_toe.enumerations.TailleGrille;
import ntro.messages.MessagePourEnvoi;

public interface MsgTransmettreTaillePourEnvoi extends MessagePourEnvoi {
	
	void setTailleGrille(TailleGrille tailleGrille);

}
