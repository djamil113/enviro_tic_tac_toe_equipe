package tic_tac_toe.messages.transmettre_numeropartie;

import ntro.messages.MessagePourEnvoi;
import tic_tac_toe.enumerations.numPartie;

public interface MsgTransmettreNumeroPartiePourEnvoi extends MessagePourEnvoi {
	
	void setNumPartie(numPartie numeroPartie);

}
