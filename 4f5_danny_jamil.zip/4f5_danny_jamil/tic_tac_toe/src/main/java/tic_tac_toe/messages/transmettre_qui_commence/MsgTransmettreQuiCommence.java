package tic_tac_toe.messages.transmettre_qui_commence;

import tic_tac_toe.enumerations.Forme;
import ntro.debogage.J;
import ntro.messages.Message;

public class MsgTransmettreQuiCommence extends Message<MsgTransmettreQuiCommencePourEnvoi, 
                                             MsgTransmettreQuiCommenceRecu>

					         implements MsgTransmettreQuiCommencePourEnvoi, 
					                    MsgTransmettreQuiCommenceRecu {
	
	private Forme quiCommence;

	@Override
	public Forme getQuiCommence() {
		J.appel(this);
		
		return quiCommence;
	}

	@Override
	public void setQuiCommence(Forme quiCommence) {
		J.appel(this);
		
		this.quiCommence = quiCommence;
	}
}
