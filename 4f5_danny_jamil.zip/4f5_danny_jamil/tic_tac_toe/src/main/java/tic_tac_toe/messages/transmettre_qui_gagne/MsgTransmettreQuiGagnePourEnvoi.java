package tic_tac_toe.messages.transmettre_qui_gagne;

import ntro.messages.MessagePourEnvoi;

public interface MsgTransmettreQuiGagnePourEnvoi extends MessagePourEnvoi {
	
	void setQuiGagne(String quiGagne);

}
