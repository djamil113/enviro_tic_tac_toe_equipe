package tic_tac_toe.messages.transmettre_Couleurs;

import ntro.debogage.J;
import ntro.messages.Message;
import tic_tac_toe.enumerations.Couleurs;

public class MsgTransmettreCouleurBack
		extends Message<MsgTransmettreCouleurBackPourEnvoie, MsgTransmettreCouleurBackRecue>

		implements MsgTransmettreCouleurBackPourEnvoie, MsgTransmettreCouleurBackRecue {

	private Couleurs couleurFond;

	@Override
	public Couleurs getCouleurBack() {
		J.appel(this);

		return couleurFond;
	}

	@Override
	public void setCouleurBack(Couleurs couleurFond) {
	J.appel(this);
		
		this.couleurFond = couleurFond;
	}

}