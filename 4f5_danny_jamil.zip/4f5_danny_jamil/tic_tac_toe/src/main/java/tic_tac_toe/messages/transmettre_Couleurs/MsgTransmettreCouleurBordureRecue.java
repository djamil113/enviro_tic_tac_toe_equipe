package tic_tac_toe.messages.transmettre_Couleurs;

import ntro.messages.MessageRecu;
import tic_tac_toe.enumerations.Couleurs;

public interface MsgTransmettreCouleurBordureRecue extends MessageRecu {

	Couleurs getCouleurBordure();
}
