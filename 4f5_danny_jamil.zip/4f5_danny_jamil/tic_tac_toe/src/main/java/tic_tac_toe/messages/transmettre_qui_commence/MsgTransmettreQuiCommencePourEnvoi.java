package tic_tac_toe.messages.transmettre_qui_commence;

import tic_tac_toe.enumerations.Forme;
import ntro.messages.MessagePourEnvoi;

public interface MsgTransmettreQuiCommencePourEnvoi extends MessagePourEnvoi {
	
	void setQuiCommence(Forme quiCommence);

}
