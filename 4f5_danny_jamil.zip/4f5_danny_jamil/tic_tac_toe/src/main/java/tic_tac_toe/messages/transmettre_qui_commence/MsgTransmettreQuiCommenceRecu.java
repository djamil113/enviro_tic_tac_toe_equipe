package tic_tac_toe.messages.transmettre_qui_commence;

import tic_tac_toe.enumerations.Forme;
import ntro.messages.MessageRecu;

public interface MsgTransmettreQuiCommenceRecu extends MessageRecu {
	
	Forme getQuiCommence();

}
