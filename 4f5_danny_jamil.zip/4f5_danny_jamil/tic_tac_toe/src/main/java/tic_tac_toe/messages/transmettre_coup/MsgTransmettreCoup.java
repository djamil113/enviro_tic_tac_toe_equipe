package tic_tac_toe.messages.transmettre_coup;

import ntro.debogage.J;
import ntro.messages.Message;

public class MsgTransmettreCoup extends Message<MsgTransmettreCoupPourEnvoi, 
                                             MsgTransmettreCoupRecu>

					         implements MsgTransmettreCoupPourEnvoi, 
					                    MsgTransmettreCoupRecu {
	
	private int indiceColonne;
	private int indiceRangee;

	@Override
	public int getIndiceColonne() {
		J.appel(this);

		return indiceColonne;
	}

	@Override
	public void setIndiceColonne(int indiceColonne) {
		J.appel(this);
		
		this.indiceColonne = indiceColonne;
	}

	@Override
	public int getIndiceRangee() {
		J.appel(this);
		
		return indiceRangee;
	}
	
	@Override
	public void setIndiceRangee(int indiceRangee) {
		J.appel(this);
		
		this.indiceRangee = indiceRangee;
	}

}
