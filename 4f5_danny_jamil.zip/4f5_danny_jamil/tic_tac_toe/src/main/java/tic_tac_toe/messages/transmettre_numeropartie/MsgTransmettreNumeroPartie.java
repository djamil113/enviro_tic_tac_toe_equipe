package tic_tac_toe.messages.transmettre_numeropartie;

import ntro.debogage.J;
import ntro.messages.Message;
import tic_tac_toe.enumerations.numPartie;

public class MsgTransmettreNumeroPartie
		extends Message<MsgTransmettreNumeroPartiePourEnvoi, MsgTransmettreNumeroPartieRecu>

		implements MsgTransmettreNumeroPartiePourEnvoi, MsgTransmettreNumeroPartieRecu {

	private numPartie numeroPartie;

	@Override
	public String getNumPartie() {
		J.appel(this);
		return numeroPartie.toString();
	}

	@Override
	public void setNumPartie(numPartie numeroPartie) {
		J.appel(this);

		this.numeroPartie = numeroPartie;

	}

}
