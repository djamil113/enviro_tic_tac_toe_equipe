package tic_tac_toe.messages.nouvelle_partie_reseau;

import tic_tac_toe.pages.parametres.Parametres;
import ntro.messages.MessagePourEnvoi;

public interface MsgNouvellePartiePourEnvoi extends MessagePourEnvoi {
	
	void setParametres(Parametres parametres);

}
