package tic_tac_toe.messages.transmettre_numeropartie;

import ntro.messages.MessageRecu;
import tic_tac_toe.enumerations.numPartie;

public interface MsgTransmettreNumeroPartieRecu extends MessageRecu {
	
	String getNumPartie();

}
