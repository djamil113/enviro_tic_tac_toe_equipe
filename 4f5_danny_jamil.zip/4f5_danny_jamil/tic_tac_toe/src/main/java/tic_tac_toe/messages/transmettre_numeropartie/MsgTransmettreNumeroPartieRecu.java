package tic_tac_toe.messages.transmettre_numeropartie;

import ntro.messages.MessageRecu;

public interface MsgTransmettreNumeroPartieRecu extends MessageRecu {
	
	String getNumPartie();

}
