package tic_tac_toe.messages.transmettre_coup;

import ntro.messages.MessageRecu;

public interface MsgTransmettreCoupRecu extends MessageRecu {
	
	int getIndiceColonne();
	int getIndiceRangee();

}
