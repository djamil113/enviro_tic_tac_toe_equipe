package tic_tac_toe.messages.transmettre_Couleurs;

import ntro.debogage.J;
import ntro.messages.Message;
import tic_tac_toe.enumerations.Couleurs;

public class MsgTransmettreCouleurBordure
extends Message<MsgTransmettreCouleurBordurePourEnvoie, MsgTransmettreCouleurBordureRecue>

implements MsgTransmettreCouleurBordurePourEnvoie, MsgTransmettreCouleurBordureRecue {

private Couleurs couleurBordure;

@Override
public Couleurs getCouleurBordure() {
J.appel(this);

return couleurBordure;
}

@Override
public void setCouleurBordure(Couleurs couleurBordure) {
J.appel(this);

this.couleurBordure = couleurBordure;
}

}
