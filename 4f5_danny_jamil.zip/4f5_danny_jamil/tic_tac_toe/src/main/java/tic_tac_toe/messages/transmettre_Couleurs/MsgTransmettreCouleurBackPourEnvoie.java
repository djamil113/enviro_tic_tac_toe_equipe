package tic_tac_toe.messages.transmettre_Couleurs;

import ntro.messages.MessagePourEnvoi;
import tic_tac_toe.enumerations.Couleurs;


public interface MsgTransmettreCouleurBackPourEnvoie extends MessagePourEnvoi {
	
	void setCouleurBack(Couleurs couleurFond);

}
