package tic_tac_toe.messages.transmettre_qui_gagne;

import ntro.debogage.J;
import ntro.messages.Message;

public class MsgTransmettreQuiGagne extends Message<MsgTransmettreQuiGagnePourEnvoi, MsgTransmettreQuiGagneRecu>

		implements MsgTransmettreQuiGagnePourEnvoi, MsgTransmettreQuiGagneRecu {

	private String quiGagne;

	@Override
	public String getQuiGagne() {
		J.appel(this);

		return quiGagne.toString();
	}

	@Override
	public void setQuiGagne(String quiGagne) {
		J.appel(this);

		this.quiGagne = quiGagne;		
	}
}
