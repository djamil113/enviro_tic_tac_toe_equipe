package tic_tac_toe.messages.transmettre_qui_gagne;

import ntro.messages.MessageRecu;

public interface MsgTransmettreQuiGagneRecu extends MessageRecu {
	
	String getQuiGagne();
	

}
