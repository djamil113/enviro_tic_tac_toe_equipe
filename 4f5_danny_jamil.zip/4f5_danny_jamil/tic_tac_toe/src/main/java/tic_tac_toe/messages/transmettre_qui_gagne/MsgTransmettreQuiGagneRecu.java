package tic_tac_toe.messages.transmettre_qui_gagne;

import ntro.messages.MessageRecu;
import tic_tac_toe.enumerations.Winner;

public interface MsgTransmettreQuiGagneRecu extends MessageRecu {
	
	String getQuiGagne();
	

}
