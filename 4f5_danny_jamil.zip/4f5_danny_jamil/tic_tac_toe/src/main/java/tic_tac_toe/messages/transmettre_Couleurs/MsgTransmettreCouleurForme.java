package tic_tac_toe.messages.transmettre_Couleurs;

import ntro.debogage.J;
import ntro.messages.Message;
import tic_tac_toe.enumerations.Couleurs;

public class MsgTransmettreCouleurForme
extends Message<MsgTransmettreCouleurFormePourEnvoie, MsgTransmettreCouleurFormeRecue>

implements MsgTransmettreCouleurFormePourEnvoie, MsgTransmettreCouleurFormeRecue {

private Couleurs couleurForme;

@Override
public Couleurs getCouleurForme() {
J.appel(this);

return couleurForme;
}

@Override
public void setCouleurForme(Couleurs couleurForme) {
J.appel(this);

this.couleurForme = couleurForme;
}

}
