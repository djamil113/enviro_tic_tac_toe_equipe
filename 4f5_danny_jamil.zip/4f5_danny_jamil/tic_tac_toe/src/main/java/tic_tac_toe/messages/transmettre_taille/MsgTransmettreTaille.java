package tic_tac_toe.messages.transmettre_taille;

import tic_tac_toe.enumerations.TailleGrille;
import ntro.debogage.J;
import ntro.messages.Message;

public class MsgTransmettreTaille extends Message<MsgTransmettreTaillePourEnvoi, 
                                             MsgTransmettreTailleRecu>

					         implements MsgTransmettreTaillePourEnvoi, 
					                    MsgTransmettreTailleRecu {
	
	private TailleGrille tailleGrille;

	@Override
	public TailleGrille getTailleGrille() {
		J.appel(this);

		return tailleGrille;
	}

	@Override
	public void setTailleGrille(TailleGrille tailleGrille) {
		J.appel(this);
		
		this.tailleGrille = tailleGrille;
	}
}
