package tic_tac_toe.client;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ntro.debogage.DoitEtre;
import ntro.debogage.Erreur;
import ntro.debogage.J;
import ntro.javafx.ChargeurDeVue;
import ntro.javafx.DialogueModal;
import ntro.javafx.Initialisateur;
import ntro.mvc.controleurs.FabriqueControleur;
import ntro.systeme.Systeme;
import tic_tac_toe.pages.accueil.ControleurAccueil;
import tic_tac_toe.pages.accueil.VueAccueil;

import static tic_tac_toe.Constantes.*;
import static tic_tac_toe.Constantes.AJUSTEMENT_TAILLE_PIXELS;
import static tic_tac_toe.Constantes.TAILLE_POLICE;
import static tic_tac_toe.Constantes.TAILLE_POLICE_MAX;
import static tic_tac_toe.Constantes.TAILLE_POLICE_MIN;
import static tic_tac_toe.Constantes.HAUTEUR_PIXELS;
import static tic_tac_toe.Constantes.LARGEUR_PIXELS;

import java.net.URI;
import java.net.URISyntaxException;

public class MonClient extends Application {

	static {
		Initialisateur.initialiser();
		J.appel(MonClient.class);
	}

	private static MonClientWebSocket clientWebSocket;
	
	public static void main(String[] args) {
		J.appel(MonClient.class);
		launch(args);
	}

	@Override
	public void start(Stage fenetrePrincipale) throws Exception {
		J.appel(this);

		DialogueModal.enregistreFenetrePrincipale(fenetrePrincipale);
		
		connecterAuServeur();
		
		calculerAjustementPixels();

		Scene scene = instancierControleurAccueil();

		fenetrePrincipale.setScene(scene);
		
		ajusterTailles(fenetrePrincipale, scene);

		ajusterTailles(fenetrePrincipale, scene);

		capterEvenementFermeture(fenetrePrincipale);

		fenetrePrincipale.show();
	}

	private void capterEvenementFermeture(Stage fenetrePrincipale) {
		J.appel(this);

		fenetrePrincipale.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				J.appel(this);

				Systeme.quitter();
			}
		});
	}

	private Scene instancierControleurAccueil() {
		J.appel(this);

		ChargeurDeVue<VueAccueil> chargeur;
		chargeur = new ChargeurDeVue<VueAccueil>(CHEMIN_PRINCIPAL_FXML, 
												 CHEMIN_PRINCIPAL_CSS, 
												 CHEMIN_CHAINES);

		VueAccueil vue = chargeur.getVue();

		DoitEtre.nonNul(vue);

		FabriqueControleur.creerControleur(ControleurAccueil.class, vue);

		Scene scene = chargeur.nouvelleScene(LARGEUR_PIXELS * AJUSTEMENT_TAILLE_PIXELS,
                							 HAUTEUR_PIXELS * AJUSTEMENT_TAILLE_PIXELS);
		return scene;
	}

	private void ajusterTailles(Stage fenetrePrincipale, Scene scene) {
		J.appel(this);
		
		ajusterTaillePolice(scene);

		fenetrePrincipale.setMinWidth(LARGEUR_PIXELS_MIN * AJUSTEMENT_TAILLE_PIXELS);
		fenetrePrincipale.setMinHeight(HAUTEUR_PIXELS_MIN * AJUSTEMENT_TAILLE_PIXELS);

		fenetrePrincipale.setWidth(LARGEUR_PIXELS * AJUSTEMENT_TAILLE_PIXELS);
		fenetrePrincipale.setHeight(HAUTEUR_PIXELS * AJUSTEMENT_TAILLE_PIXELS);
	}

	private void calculerAjustementPixels() {
		J.appel(this);

		double largeurEcran = Screen.getPrimary().getVisualBounds().getWidth();
		double hauteurEcran = Screen.getPrimary().getVisualBounds().getHeight();
		double tailleEcran = Math.max(largeurEcran, hauteurEcran);

		AJUSTEMENT_TAILLE_PIXELS = 1.2 * tailleEcran / 1920.0;
	}

	private void ajusterTaillePolice(Scene scene) {
		J.appel(this);

		int taillePolice = calculerTaillePolice();

		String cssTaillePolice = String.format("-fx-font-size: %dpx;", taillePolice);

		scene.getRoot().setStyle(cssTaillePolice);
	}

	private int calculerTaillePolice() {
		J.appel(this);

		int taillePolice = (int) Math.ceil(TAILLE_POLICE * AJUSTEMENT_TAILLE_PIXELS);

		if (taillePolice < TAILLE_POLICE_MIN) {

			taillePolice = TAILLE_POLICE_MIN;

		} else if (taillePolice > TAILLE_POLICE_MAX) {

			taillePolice = TAILLE_POLICE_MAX;
		}

		return taillePolice;
	}

	private void connecterAuServeur() {
		J.appel(this);

		URI uriServeur = null;

		try {

			uriServeur = new URI(ADRESSE_SERVEUR);

		} catch (URISyntaxException e) {

			Erreur.fatale("L'adresse du serveur est mal formée: " + ADRESSE_SERVEUR, e);
		}

		connecterAuServeur(uriServeur);
	}

	private void connecterAuServeur(URI uriServeur) {
		J.appel(this);

		clientWebSocket = new MonClientWebSocket(uriServeur);

		Erreur.avertissement("Tentative de connexion au serveur... ");

		try {

			clientWebSocket.connectBlocking();

		} catch (InterruptedException e) {

			Erreur.nonFatale("Tentative de connexion annulée", e);
		}
	}

	public static boolean siConnecteAuServeur() {
		J.appel(MonClient.class);

		return clientWebSocket != null && clientWebSocket.isOpen();
	}
}
