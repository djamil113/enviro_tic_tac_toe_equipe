package tic_tac_toe.client;

import java.net.URI;
import ntro.javafx.ClientWebSocketFX;

public class MonClientWebSocket extends ClientWebSocketFX {

	public MonClientWebSocket(URI serverUri) {
		super(serverUri);
	}

}
